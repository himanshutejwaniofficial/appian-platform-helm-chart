{{/*
		T-SHIRT SIZE: large
*/}}

{{/* *********************************************************
		Zookeeper
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.large.zookeeper.storageSize" -}}
{{- "15Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.zookeeper.minHeap" -}}
{{- "128m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.zookeeper.maxHeap" -}}
{{- "256m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.zookeeper.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.zookeeper.cpuLimits" -}}
{{- "200m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.zookeeper.memoryRequests" -}}
{{- "307Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.zookeeper.memoryLimits" -}}
{{- "448Mi" }}
{{- end }}

{{/* *********************************************************
		Kafka
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.large.kafka.storageSize" -}}
{{- "60Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.kafka.minHeap" -}}
{{- "512m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.kafka.maxHeap" -}}
{{- "1024m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.kafka.cpuRequests" -}}
{{- "500m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.kafka.cpuLimits" -}}
{{- "2000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.kafka.memoryRequests" -}}
{{- "1229Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.kafka.memoryLimits" -}}
{{- "1792Mi" }}
{{- end }}

{{/* *********************************************************
		Search Server
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.large.searchServer.storageSize" -}}
{{- "15Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.searchServer.heap" -}}
{{- "4000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.searchServer.cpuRequests" -}}
{{- "200m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.searchServer.cpuLimits" -}}
{{- "3000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.searchServer.memoryRequests" -}}
{{- "5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.searchServer.memoryLimits" -}}
{{- "10Gi" }}
{{- end }}

{{/* *********************************************************
	Data Server
	*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.large.dataServer.storageSize" -}}
{{- "40Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.dataServer.rtsCount" -}}
{{- 8 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.dataServer.rtsThreads" -}}
{{- 4 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.dataServer.rtsMemoryLimit" -}}
{{- "8GiB" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.dataServer.cpuRequests" -}}
{{- "5" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.dataServer.cpuLimits" -}}
{{- "8" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.dataServer.memoryRequests" -}}
{{- "20Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.dataServer.memoryLimits" -}}
{{- "36Gi" }}
{{- end }}

{{/* *********************************************************
		Service Manager
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.large.serviceManager.storageSize" -}}
{{- if .Values.storage.haSharedDataPvc }}
{{- "2Gi" }}
{{- else }}
{{- "5Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.serviceManager.komodoDirectMemMax" -}}
{{- "768m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.serviceManager.komodoHeapMax" -}}
{{- "1536m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.serviceManager.exec.cpuRequests" -}}
{{- "1800m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.serviceManager.analytics.cpuRequests" -}}
{{- "1000m" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.large.serviceManager.tier2.cpuRequests" -}}
{{- "1500m" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.large.serviceManager.default.cpuRequests" -}}
{{- "750m" }}
{{- end }}

{{/* default: cpu limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.large.serviceManager.default.cpuLimits" -}}
{{- "3000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.serviceManager.exec.memoryRequests" -}}
{{- "12.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.serviceManager.analytics.memoryRequests" -}}
{{- "6.5Gi" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.large.serviceManager.tier2.memoryRequests" -}}
{{- "10Gi" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.large.serviceManager.default.memoryRequests" -}}
{{- "5Gi" }}
{{- end }}

{{/* default: memory limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.large.serviceManager.default.memoryLimits" -}}
{{- "128Gi" }}
{{- end }}

{{/* *********************************************************
		Webapp
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.large.webapp.storageSize" -}}
{{- if .Values.storage.haSharedDataPvc }}
{{- "40Gi" }}
{{- else }}
{{- "75Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.webapp.maxHeapSize" -}}
{{- "6144m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.webapp.cpuRequests" -}}
{{- "6" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.webapp.cpuLimits" -}}
{{- "12" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.webapp.memoryRequests" -}}
{{- "9Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.webapp.memoryLimits" -}}
{{- "13Gi" }}
{{- end }}

{{/* *********************************************************
		httpd
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.large.httpd.cpuRequests" -}}
{{- "700m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.httpd.cpuLimits" -}}
{{- "1000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.httpd.memoryRequests" -}}
{{- "800Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.large.httpd.memoryLimits" -}}
{{- "1.5Gi" }}
{{- end }}
