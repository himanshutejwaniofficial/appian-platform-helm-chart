{{/*
		T-SHIRT SIZE: medium
*/}}

{{/* *********************************************************
		Zookeeper
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.medium.zookeeper.storageSize" -}}
{{- "10Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.zookeeper.minHeap" -}}
{{- "128m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.zookeeper.maxHeap" -}}
{{- "256m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.zookeeper.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.zookeeper.cpuLimits" -}}
{{- "200m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.zookeeper.memoryRequests" -}}
{{- "307Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.zookeeper.memoryLimits" -}}
{{- "448Mi" }}
{{- end }}

{{/* *********************************************************
		Kafka
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.medium.kafka.storageSize" -}}
{{- "30Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.kafka.minHeap" -}}
{{- "512m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.kafka.maxHeap" -}}
{{- "1024m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.kafka.cpuRequests" -}}
{{- "500m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.kafka.cpuLimits" -}}
{{- "2000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.kafka.memoryRequests" -}}
{{- "1229Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.kafka.memoryLimits" -}}
{{- "1792Mi" }}
{{- end }}

{{/* *********************************************************
		Search Server
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.medium.searchServer.storageSize" -}}
{{- "10Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.searchServer.heap" -}}
{{- "1280m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.searchServer.cpuRequests" -}}
{{- "200m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.searchServer.cpuLimits" -}}
{{- "500m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.searchServer.memoryRequests" -}}
{{- "1.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.searchServer.memoryLimits" -}}
{{- "3Gi" }}
{{- end }}

{{/* *********************************************************
	Data Server
	*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.medium.dataServer.storageSize" -}}
{{- "20Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.dataServer.rtsCount" -}}
{{- 4 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.dataServer.rtsThreads" -}}
{{- 4 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.dataServer.rtsMemoryLimit" -}}
{{- "4GiB" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.dataServer.cpuRequests" -}}
{{- "2" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.dataServer.cpuLimits" -}}
{{- "4" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.dataServer.memoryRequests" -}}
{{- "10Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.dataServer.memoryLimits" -}}
{{- "20Gi" }}
{{- end }}

{{/* *********************************************************
		Service Manager
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.storageSize" -}}
{{- if .Values.storage.haSharedDataPvc }}
{{- "2Gi" }}
{{- else }}
{{- "5Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.komodoDirectMemMax" -}}
{{- "512m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.komodoHeapMax" -}}
{{- "1g" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.exec.cpuRequests" -}}
{{- "1000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.analytics.cpuRequests" -}}
{{- "200m" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.tier2.cpuRequests" -}}
{{- "500m" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.default.cpuRequests" -}}
{{- "200m" }}
{{- end }}

{{/* default: cpu limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.default.cpuLimits" -}}
{{- "2500m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.exec.memoryRequests" -}}
{{- "8Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.analytics.memoryRequests" -}}
{{- "4Gi" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.tier2.memoryRequests" -}}
{{- "5Gi" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.default.memoryRequests" -}}
{{- "2Gi" }}
{{- end }}

{{/* default: memory limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.medium.serviceManager.default.memoryLimits" -}}
{{- "64Gi" }}
{{- end }}

{{/* *********************************************************
		Webapp
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.medium.webapp.storageSize" -}}
{{- if .Values.storage.haSharedDataPvc }}
{{- "40Gi" }}
{{- else }}
{{- "75Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.webapp.maxHeapSize" -}}
{{- "4096m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.webapp.cpuRequests" -}}
{{- "4" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.webapp.cpuLimits" -}}
{{- "8" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.webapp.memoryRequests" -}}
{{- "6Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.webapp.memoryLimits" -}}
{{- "8Gi" }}
{{- end }}

{{/* *********************************************************
		httpd
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.medium.httpd.cpuRequests" -}}
{{- "400m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.httpd.cpuLimits" -}}
{{- "750m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.httpd.memoryRequests" -}}
{{- "700Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.medium.httpd.memoryLimits" -}}
{{- "1.2Gi" }}
{{- end }}
