{{/*
Expand the name of the chart.
*/}}
{{- define "appian-platform-cs.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "appian-platform-cs.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "appian-platform-cs.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "appian-platform-cs.labels" -}}
helm.sh/chart: {{ include "appian-platform-cs.chart" . }}
{{ include "appian-platform-cs.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "appian-platform-cs.selectorLabels" -}}
app.kubernetes.io/name: {{ include "appian-platform-cs.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "appian-platform-cs.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "appian-platform-cs.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
----- CUSTOM HELPERS FROM HERE -----
*/}}

{{/*
Renders a value that contains template perhaps with scope if the scope is present.
Usage:
{{ include "common.tplvalues.render" ( dict "value" .Values.path.to.the.Value "context" $ ) }}
{{ include "common.tplvalues.render" ( dict "value" .Values.path.to.the.Value "context" $ "scope" $app ) }}
*/}}
{{- define "common.tplvalues.render" -}}
{{- $value := typeIs "string" .value | ternary .value (.value | toYaml) }}
{{- if contains "{{" (toJson .value) }}
  {{- if .scope }}
      {{- tpl (cat "{{- with $.RelativeScope -}}" $value "{{- end }}") (merge (dict "RelativeScope" .scope) .context) }}
  {{- else }}
    {{- tpl $value .context }}
  {{- end }}
{{- else }}
    {{- $value }}
{{- end }}
{{- end -}}

{{/*
Combine minimal image repository and optional tag
*/}}
{{- define "appian-platform-cs.minimalImageWithTag" -}}
{{- if .Values.images.minimal.tag }}
{{- printf "%s:%s" .Values.images.minimal.repository .Values.images.minimal.tag }}
{{- else }}
{{- .Values.images.minimal.repository }}
{{- end }}
{{- end }}

{{/*
httpd replicas
*/}}
{{- define "appian-platform-cs.httpdReplicas" -}}
{{- if .Values.httpd.replicas }}
{{- .Values.httpd.replicas }}
{{- else }}
{{- .Values.highAvailability | ternary .Values.webapp.replicas 1 | default 3 }}
{{- end }}
{{- end }}

{{- /* Apply a signature annotation to identify sites that have used this chart to generate their spec*/}}
{{- define "appian-platform-cs.signature.annotationSection" -}}
annotations:
  cs.k8s.appian.com/helm-chart: {{ .Chart.Version }}
{{- end }}

{{/*
DEPRECATED - THIS HELPER FUNCTION IS NO LONGER USED. IT IS KEPT AS AN EXAMPLE ONLY.
Default for dataServer.rts.queryMemoryCircuitBreakerThresholdBytes
*/}}
{{- define "appian-platform-cs.calculateRtsQueryMemoryCBDefaultThreshold" -}}
{{- $rtsCount := . | int -}}
{{- if le $rtsCount 2 }}
  {{- 500000000 }}
{{- else if le $rtsCount 4 }}
  {{- 1000000000 }}
{{- else if le $rtsCount 8 }}
  {{- 2000000000 }}
{{- else if le $rtsCount 12 }}
  {{- 4000000000 }}
{{- else }}
  {{- 4000000000 }}
{{- end }}
{{- end }}


{{/*
Validate that additionalCustomProperties does not collide with any custom property
that this chart manages itself. Setting a managed property here would render a
duplicate key under spec.customProperties, whose behaviour in Appian is undefined
(silent override or manifest rejection). We fail fast instead.

The reserved set is CONTEXTUAL, not strict:
  - Heap / RTS / process-engine keys are ALWAYS managed by the chart.
  - SMTP keys (conf.mailhandler.*, conf.suite.MAIL_*) are only managed when
    .Values.smtp.host is set. When it is unset, the chart emits none of them, so a
    user migrating an existing site may supply them raw via additionalCustomProperties.
  - Metrics keys are only managed when .Values.metricsAuthToken is set.

Each reserved key maps to the friendly Helm value that governs it, so the error can
point the user at the correct way to set it (the Appian property key and the Helm
value name often differ).

IMPORTANT (maintainers): whenever you add, remove, or conditionalise a key under
spec.customProperties in appian.yaml, update the corresponding entry (and its
condition) in this helper. See .kiro/steering/helm-chart-practices.md.

Usage:
{{ include "appian-platform-cs.validateAdditionalCustomProperties" . }}
*/}}
{{- define "appian-platform-cs.validateAdditionalCustomProperties" -}}
{{- $reserved := dict
  "conf.appserver.minHeapSize" "webapp.minHeap"
  "conf.appserver.maxHeapSize" "webapp.maxHeap"
  "ads.adb.systemConfig__.rts.threads" "dataServer.rts.threads"
  "ads.adb.systemConfig__.rts.memory_limit" "dataServer.rts.memoryLimit"
  "server.conf.processcommon.MAX_EXEC_ENGINE_LOAD_METRIC" "serviceManager.maxExecEngineLoadMetric"
  "server.conf.processcommon.AUTODELETE_ARCHIVES_DELAY_DAYS" "webapp.autodeleteArchivesDelayDays"
-}}
{{- if .Values.metricsAuthToken -}}
{{- $_ := set $reserved "appian.feature.selfManagedMonitoring" "metricsAuthToken" -}}
{{- $_ := set $reserved "metricsauthtoken" "metricsAuthToken" -}}
{{- end -}}
{{- if .Values.smtp.host -}}
{{- $_ := set $reserved "conf.mailhandler.ntf_sndr_addr" "smtp.senderAddress" -}}
{{- $_ := set $reserved "conf.mailhandler.email.domain" "smtp.senderDomain" -}}
{{- $_ := set $reserved "conf.mailhandler.mail.smtp.host" "smtp.host" -}}
{{- $_ := set $reserved "conf.mailhandler.mail.smtp.auth" "smtp.auth" -}}
{{- $_ := set $reserved "conf.mailhandler.mail.user" "smtp.user" -}}
{{- $_ := set $reserved "conf.mailhandler.mail.transport.protocol" "smtp.protocol" -}}
{{- $_ := set $reserved "conf.mailhandler.mail.smtp.starttls.enable" "smtp.starttlsEnabled" -}}
{{- $_ := set $reserved "conf.mailhandler.mail.smtp.starttls.required" "smtp.starttlsRequired" -}}
{{- $_ := set $reserved "conf.suite.MAIL_SCHEME" "(managed automatically when smtp.host is set)" -}}
{{- $_ := set $reserved "conf.suite.MAIL_SERVER_AND_PORT" "(managed automatically when smtp.host is set)" -}}
{{- end -}}
{{- $collisions := list -}}
{{- range $key, $val := .Values.additionalCustomProperties -}}
{{- if hasKey $reserved $key -}}
{{- $collisions = append $collisions (printf "  - %q is already managed by this chart; set it via the %q value instead (and remove it from additionalCustomProperties)." $key (get $reserved $key)) -}}
{{- end -}}
{{- end -}}
{{- if $collisions -}}
{{- $msg := printf "additionalCustomProperties contains %d custom propert%s that this chart already manages. Each managed property must be set only once.\n%s\nNote: SMTP properties (conf.mailhandler.*, conf.suite.MAIL_*) are only managed when smtp.host is set. To supply SMTP properties raw (e.g. when migrating an existing site), leave the smtp.* values unset and manage all SMTP properties via additionalCustomProperties." (len $collisions) (ternary "y" "ies" (eq (len $collisions) 1)) (join "\n" $collisions) -}}
{{- fail $msg -}}
{{- end -}}
{{- end -}}
