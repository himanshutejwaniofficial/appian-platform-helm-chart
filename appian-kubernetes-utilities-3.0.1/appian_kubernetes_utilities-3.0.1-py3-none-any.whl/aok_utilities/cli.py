"""Typer app: registers subcommands and global options for the aok CLI."""

from importlib.metadata import version
from typing import Optional

import typer

from aok_utilities.docs_viewer import app as docs_app
from aok_utilities.generator import app as generator_app
from aok_utilities.migration_converter import app as migration_converter_app
from aok_utilities.visualizer import app as visualizer_app

app = typer.Typer(
    name="aok",
    help="Appian on Kubernetes CLI utilities.",
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    """Print version and exit when --version is passed."""
    if value:
        typer.echo(f"aok {version('appian-kubernetes-utilities')}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(  # noqa: ARG001
        None,
        "--version",
        "-V",
        help="Show the version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Appian on Kubernetes CLI utilities."""


app.add_typer(generator_app, name="generate")
app.add_typer(docs_app, name="docs")
app.add_typer(migration_converter_app, name="migration-convert")
app.add_typer(visualizer_app, name="visualize")
