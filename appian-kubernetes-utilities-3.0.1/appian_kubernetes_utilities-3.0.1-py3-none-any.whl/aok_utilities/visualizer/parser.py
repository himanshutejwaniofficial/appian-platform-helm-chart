"""Resource parser: YAML loading, validation, and field extraction.

Loads an Appian site YAML (Kubernetes Custom Resource), validates its
structure, and extracts component configurations into typed dataclasses
for downstream processing by the calculator and renderer.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from aok_utilities.common.appian import COMPONENT_LIST, ENGINE_LIST, SHARDED_ENGINES
from aok_utilities.common.db import extract_db_type
from aok_utilities.common.exceptions import ConfigFileError, ValidationError
from aok_utilities.visualizer.converter import convert_cpu, convert_memory

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ResourceSpec:
    """CPU and memory requests/limits for a single pod or engine.

    All values are in normalised units: CPU in cores, memory in GiB.
    """

    cpu_request: float
    cpu_limit: float
    mem_request: float
    mem_limit: float


@dataclass(frozen=True)
class StorageSpec:
    """PVC storage specification.

    Attributes:
        storage_class: The Kubernetes storage class name.
        size: Original size value as specified in the YAML (e.g. "10Gi").
    """

    storage_class: str
    size: str


@dataclass(frozen=True)
class EngineModel:
    """A single Service Manager engine (possibly sharded).

    Attributes:
        name: Engine display name. For sharded engines, includes a
            zero-padded index suffix (e.g. "analytics - 00").
        resources: Per-engine resource specification.
    """

    name: str
    resources: ResourceSpec


@dataclass(frozen=True)
class ComponentModel:
    """Parsed configuration for a single AoK component.

    Attributes:
        name: Component name (e.g. "zookeeper", "serviceManager").
        replicas: Number of pod replicas.
        resources: Per-pod resource specification.
        storage: PVC storage spec, or None if no storage configured.
        rts_count: RTS count for dataServer only.
        heap_max: Max heap size string for webapp only.
        hpa_max_replicas: HPA max replicas for httpd only.
        engines: List of engines for serviceManager only.
        shard_count: Analytics/execution shard count for serviceManager only.
    """

    name: str
    replicas: int
    resources: ResourceSpec
    storage: StorageSpec | None
    rts_count: int | None = None
    heap_max: str = ""
    hpa_max_replicas: int | None = None
    engines: list[EngineModel] = field(default_factory=list)
    shard_count: int = 0


@dataclass(frozen=True)
class DatasourceModel:
    """A database datasource extracted from webapp config.

    Attributes:
        name: Short name extracted from the JNDI name (after last '/').
        db_type: Database type string (e.g. "mariadb", "postgresql").
        is_primary: Whether this is the primary datasource.
    """

    name: str
    db_type: str
    is_primary: bool


@dataclass(frozen=True)
class SmtpModel:
    """SMTP server configuration.

    Attributes:
        host: SMTP server hostname.
        protocol: Mail transport protocol ("smtp" or "smtps").
    """

    host: str
    protocol: str


@dataclass(frozen=True)
class IngressModel:
    """Ingress configuration.

    Attributes:
        enabled: Whether ingress is enabled in the site YAML.
        ingress_class: Ingress class string (e.g. "alb", "nginx"),
            or empty string if disabled.
    """

    enabled: bool
    ingress_class: str


@dataclass(frozen=True)
class HaModel:
    """High-availability configuration.

    Attributes:
        enabled: Whether HA is enabled (at least one HA claim is configured).
        claim_name: The HA existing claim name for display.
    """

    enabled: bool
    claim_name: str


@dataclass(frozen=True)
class ResourceTotals:
    """Aggregated resource totals for a component or site.

    All values are rounded to 3 decimal places.

    Attributes:
        cpu_request: Total CPU requests in cores.
        cpu_limit: Total CPU limits in cores.
        mem_request: Total memory requests in GiB.
        mem_limit: Total memory limits in GiB.
        rwo_storage: Total RWO storage in GiB (per-pod storage × replicas).
    """

    cpu_request: float
    cpu_limit: float
    mem_request: float
    mem_limit: float
    rwo_storage: float


@dataclass(frozen=True)
class SiteModel:
    """Complete parsed and calculated site model.

    Represents the fully-processed intermediate state between YAML parsing
    and diagram rendering / summary output.

    Attributes:
        name: Site name from metadata.name.
        version: Site version from spec.version.
        url: Site URL from spec.url.
        static_url: Static URL from spec.webapp.staticUrl.
        dynamic_url: Dynamic URL from spec.webapp.dynamicUrl.
        components: List of parsed component configurations.
        datasources: List of extracted database datasources.
        smtp: SMTP configuration, or None if not configured.
        ingress: Ingress configuration.
        ha: High-availability configuration.
        health_check_claim: Health check existing claim name (empty if not configured).
        service_type: Kubernetes service type (e.g. "ClusterIP", "LoadBalancer").
        component_totals: Per-component resource totals keyed by component name.
        site_totals: Aggregated site-wide resource totals.
    """

    name: str
    version: str
    url: str
    static_url: str
    dynamic_url: str
    components: list[ComponentModel]
    datasources: list[DatasourceModel]
    smtp: SmtpModel | None
    ingress: IngressModel
    ha: HaModel
    health_check_claim: str
    service_type: str
    component_totals: dict[str, ResourceTotals]
    site_totals: ResourceTotals


EXPECTED_API_VERSION = "crd.k8s.appian.com/v1beta1"
EXPECTED_KIND = "Appian"


def validate_site_yaml(data: dict[str, Any], path: Path) -> None:
    """Validate the structure of a parsed site YAML dictionary.

    Checks that the document contains the correct apiVersion and kind,
    and that all required keys are present.

    Args:
        data: The parsed YAML dictionary.
        path: The filesystem path to the YAML file (used in error messages).

    Raises:
        ValidationError: If apiVersion, kind, or required keys are missing/incorrect.
    """
    # Validate apiVersion
    api_version = data.get("apiVersion")
    if api_version != EXPECTED_API_VERSION:
        if api_version is None:
            raise ValidationError(path, "apiVersion", "is missing")
        raise ValidationError(
            path,
            "apiVersion",
            f"has incorrect value '{api_version}', expected '{EXPECTED_API_VERSION}'",
        )

    # Validate kind
    kind = data.get("kind")
    if kind != EXPECTED_KIND:
        if kind is None:
            raise ValidationError(path, "kind", "is missing")
        raise ValidationError(
            path,
            "kind",
            f"has incorrect value '{kind}', expected '{EXPECTED_KIND}'",
        )

    # Validate required nested keys
    required_keys: list[tuple[str, list[str]]] = [
        ("metadata.name", ["metadata", "name"]),
        ("spec.version", ["spec", "version"]),
        ("spec.url", ["spec", "url"]),
    ]

    for dotted_path, key_parts in required_keys:
        current: Any = data
        for part in key_parts:
            if not isinstance(current, dict) or part not in current:
                raise ValidationError(path, dotted_path, "is missing")
            current = current[part]


def parse_site_yaml(path: Path) -> dict[str, Any]:
    """Load and validate an Appian site YAML file.

    Reads the YAML file at the given path, validates its structure
    (apiVersion, kind, required keys), and returns the raw parsed dict.

    Args:
        path: Path to the site YAML file.

    Returns:
        The parsed YAML content as a dictionary.

    Raises:
        ConfigFileError: If the file is not found, not readable, or contains
            malformed YAML.
        ValidationError: If apiVersion, kind, or required keys are
            missing or incorrect.
    """
    # Check file existence
    if not path.exists():
        raise ConfigFileError(path, "file not found")

    # Check file readability
    if not path.is_file():
        raise ConfigFileError(path, "path is not a file")

    try:
        content = path.read_text(encoding="utf-8")
    except PermissionError:
        raise ConfigFileError(path, "file is not readable")
    except OSError as exc:
        raise ConfigFileError(path, f"unable to read file: {exc}")

    # Parse YAML
    try:
        data = yaml.safe_load(content)
    except yaml.YAMLError as exc:
        if isinstance(exc, yaml.MarkedYAMLError) and exc.problem_mark is not None:
            mark = exc.problem_mark
            reason = f"invalid YAML syntax at line {mark.line + 1}: {exc.problem}"
        else:
            reason = f"invalid YAML syntax: {exc}"
        raise ConfigFileError(path, reason)

    # Ensure parsed content is a dict (not null or scalar)
    if not isinstance(data, dict):
        raise ConfigFileError(path, "invalid YAML syntax: document is not a mapping")

    # Validate structure
    validate_site_yaml(data, path)

    return data


def extract_engines(sm_spec: dict[str, Any]) -> tuple[list[EngineModel], int]:
    """Extract engine configurations from a serviceManager spec.

    Processes all engines in ENGINE_LIST, applying per-engine resource
    overrides from ``engineOverrides`` when present and falling back to the
    serviceManager top-level ``resources`` otherwise. Sharded engines
    (analytics, execution) produce one entry per shard; non-sharded engines
    produce a single entry.

    Args:
        sm_spec: The serviceManager section of the parsed site YAML
            (e.g. ``data["spec"]["serviceManager"]``).

    Returns:
        A tuple of (list of EngineModel instances, analyticsExecShardCount).
        If shard count is 0, sharded engines produce no entries.
    """
    # Extract shard count, default to 3 if absent
    topology = sm_spec.get("topology", {}) or {}
    shard_count: int = topology.get("analyticsExecShardCount", 3)

    # Get engine overrides dict
    engine_overrides: dict[str, Any] = sm_spec.get("engineOverrides", {}) or {}

    # Get top-level serviceManager resources as fallback
    top_resources: dict[str, Any] = sm_spec.get("resources", {}) or {}

    engines: list[EngineModel] = []

    for engine in ENGINE_LIST:
        # Determine which resources to use for this engine
        override_resources = engine_overrides.get(engine, {}).get("resources", {})

        if override_resources:
            raw_resources = override_resources
        else:
            raw_resources = top_resources

        # Convert resource values to normalised ResourceSpec
        requests = raw_resources.get("requests", {}) or {}
        limits = raw_resources.get("limits", {}) or {}

        resource_spec = ResourceSpec(
            cpu_request=convert_cpu(requests.get("cpu", "0")),
            cpu_limit=convert_cpu(limits.get("cpu", "0")),
            mem_request=convert_memory(requests.get("memory", "0")),
            mem_limit=convert_memory(limits.get("memory", "0")),
        )

        # Generate entries based on whether engine is sharded
        if engine in SHARDED_ENGINES:
            for i in range(shard_count):
                engines.append(
                    EngineModel(
                        name=f"{engine} - {i:02}",
                        resources=resource_spec,
                    )
                )
        else:
            engines.append(
                EngineModel(
                    name=engine,
                    resources=resource_spec,
                )
            )

    return engines, shard_count


def _extract_resource_spec(resources: dict[str, Any] | None) -> ResourceSpec:
    """Extract and convert a resource specification from a component dict.

    Reads cpu and memory requests/limits from the standard Kubernetes
    resource structure and converts them to normalised units (cores, GiB).

    Args:
        resources: The ``resources`` dict from a component, containing
            ``requests`` and ``limits`` sub-dicts with ``cpu`` and ``memory``.
            If None, returns a zero ResourceSpec.

    Returns:
        A ResourceSpec with converted values.
    """
    if not resources:
        return ResourceSpec(cpu_request=0, cpu_limit=0, mem_request=0, mem_limit=0)

    requests = resources.get("requests", {}) or {}
    limits = resources.get("limits", {}) or {}

    cpu_request = convert_cpu(requests.get("cpu", "0"))
    cpu_limit = convert_cpu(limits.get("cpu", "0"))
    mem_request = convert_memory(requests.get("memory", "0"))
    mem_limit = convert_memory(limits.get("memory", "0"))

    return ResourceSpec(
        cpu_request=cpu_request,
        cpu_limit=cpu_limit,
        mem_request=mem_request,
        mem_limit=mem_limit,
    )


def _extract_storage_spec(component_spec: dict[str, Any]) -> StorageSpec | None:
    """Extract PVC storage specification from a component dict.

    Reads ``volumeClaimTemplateSpec.storageClassName`` and
    ``volumeClaimTemplateSpec.resources.requests.storage``.

    Args:
        component_spec: The component-level dict from the site YAML.

    Returns:
        A StorageSpec if volumeClaimTemplateSpec is present, otherwise None.
    """
    vct = component_spec.get("volumeClaimTemplateSpec")
    if not vct:
        return None

    storage_class = vct.get("storageClassName", "")
    size = ""
    vct_resources = vct.get("resources")
    if vct_resources:
        vct_requests = vct_resources.get("requests")
        if vct_requests:
            size = vct_requests.get("storage", "")

    if not storage_class and not size:
        return None

    return StorageSpec(storage_class=storage_class, size=size)


def extract_smtp(custom_props: dict[str, str] | None) -> SmtpModel | None:
    """Extract SMTP configuration from site custom properties.

    Returns None if no SMTP host is configured.

    Args:
        custom_props: The ``spec.customProperties`` dict, or None if absent.

    Returns:
        An SmtpModel with host and protocol, or None if the host is
        absent, empty, or whitespace-only.
    """
    if not custom_props:
        return None

    # Extract and trim the SMTP host
    raw_host = custom_props.get("conf.mailhandler.mail.smtp.host", "")
    host = raw_host.strip() if raw_host else ""

    if not host:
        return None

    # Extract and validate the transport protocol
    raw_protocol = custom_props.get("conf.mailhandler.mail.transport.protocol", "")
    protocol = raw_protocol.lower().strip() if raw_protocol else ""

    if protocol not in ("smtp", "smtps"):
        protocol = "smtp"

    return SmtpModel(host=host, protocol=protocol)


def extract_ingress(spec: dict[str, Any]) -> IngressModel:
    """Extract ingress configuration from the site YAML spec.

    Reads the ``spec.ingress`` section and determines whether ingress is
    enabled. If enabled, extracts the ingress class from ``ingressClassName``
    first, falling back to the ``kubernetes.io/ingress.class`` annotation.

    Args:
        spec: The ``spec`` section of the parsed site YAML dictionary.

    Returns:
        An IngressModel with enabled=True and the extracted ingress class,
        or IngressModel(enabled=False, ingress_class="") if ingress is
        disabled or absent.
    """
    ingress = spec.get("ingress", {})
    if not isinstance(ingress, dict):
        return IngressModel(enabled=False, ingress_class="")

    if not ingress.get("enabled", False):
        return IngressModel(enabled=False, ingress_class="")

    # Try ingressClassName first
    ingress_class = ingress.get("ingressClassName", "")

    # Fall back to annotation if ingressClassName is empty/absent
    if not ingress_class:
        annotations = ingress.get("annotations", {}) or {}
        ingress_class = annotations.get("kubernetes.io/ingress.class", "")

    return IngressModel(enabled=True, ingress_class=ingress_class)


def detect_ha(spec: dict[str, Any]) -> HaModel:
    """Detect high-availability configuration from the site YAML spec.

    Checks ``spec.webapp.haExistingClaim`` and
    ``spec.serviceManager.haExistingClaim`` for non-whitespace content.
    Prefers the webapp claim for the display name; falls back to the
    serviceManager claim if webapp is absent or whitespace-only.

    Args:
        spec: The ``spec`` section of the parsed site YAML dictionary.

    Returns:
        An HaModel with enabled=True and the claim name if HA is configured,
        or HaModel(enabled=False, claim_name="") otherwise.
    """
    webapp_claim_raw = spec.get("webapp", {}).get("haExistingClaim", "")
    webapp_claim = webapp_claim_raw.strip() if webapp_claim_raw else ""

    sm_claim_raw = spec.get("serviceManager", {}).get("haExistingClaim", "")
    sm_claim = sm_claim_raw.strip() if sm_claim_raw else ""

    if webapp_claim:
        return HaModel(enabled=True, claim_name=webapp_claim)
    elif sm_claim:
        return HaModel(enabled=True, claim_name=sm_claim)
    else:
        return HaModel(enabled=False, claim_name="")


def extract_components(spec: dict[str, Any], custom_properties: dict[str, str] | None = None) -> list[ComponentModel]:
    """Extract component configurations from a parsed site YAML spec section.

    Iterates over COMPONENT_LIST and extracts replicas, storage, and resource
    specifications for each component. Handles special cases:
    - dataServer: extracts ``topology.rtsCount``
    - webapp: extracts ``conf.appserver.maxHeapSize`` from custom_properties
    - httpd: falls back to ``hpa.maxReplicas`` if replicas is None or 0

    Components absent from the spec are returned with 0 replicas, no storage,
    and zero resources. The serviceManager ``engines`` list is NOT populated
    here (see ``extract_engines`` for that).

    Args:
        spec: The ``spec`` section of the parsed site YAML dictionary.
        custom_properties: The ``spec.customProperties`` dict, or None if absent.

    Returns:
        A list of ComponentModel instances in COMPONENT_LIST order.
    """
    if custom_properties is None:
        custom_properties = {}

    components: list[ComponentModel] = []

    for component_name in COMPONENT_LIST:
        component_spec = spec.get(component_name)

        # Missing component defaults to zero everything
        if not component_spec or not isinstance(component_spec, dict):
            components.append(
                ComponentModel(
                    name=component_name,
                    replicas=0,
                    resources=ResourceSpec(cpu_request=0, cpu_limit=0, mem_request=0, mem_limit=0),
                    storage=None,
                )
            )
            logger.debug("Component '%s' not found in spec, defaulting to zero", component_name)
            continue

        # Extract replicas
        replicas = component_spec.get("replicas")
        if replicas is None:
            replicas = 0

        # Extract resources
        resources = _extract_resource_spec(component_spec.get("resources"))

        # Extract storage
        storage = _extract_storage_spec(component_spec)

        # --- Component-specific handling ---

        # dataServer: extract rtsCount
        rts_count: int | None = None
        if component_name == "dataServer":
            topology = component_spec.get("topology")
            if isinstance(topology, dict):
                rts_val = topology.get("rtsCount")
                if rts_val is not None:
                    rts_count = int(rts_val)

        # webapp: extract maxHeapSize from custom properties
        heap_max: str = ""
        if component_name == "webapp":
            heap_max = custom_properties.get("conf.appserver.maxHeapSize", "")

        # httpd: HPA fallback for replicas
        hpa_max_replicas: int | None = None
        if component_name == "httpd":
            if not replicas:  # None or 0
                hpa = component_spec.get("hpa")
                if isinstance(hpa, dict):
                    hpa_max = hpa.get("maxReplicas")
                    if hpa_max is not None and int(hpa_max) > 0:
                        hpa_max_replicas = int(hpa_max)
                        replicas = hpa_max_replicas
                    else:
                        replicas = 0
                else:
                    replicas = 0

        # serviceManager: extract shard_count for reference (engines populated separately)
        shard_count: int = 0
        if component_name == "serviceManager":
            topology = component_spec.get("topology")
            if isinstance(topology, dict):
                shard_val = topology.get("analyticsExecShardCount")
                if shard_val is not None:
                    shard_count = int(shard_val)
                else:
                    shard_count = 3  # default per Requirement 4.2
            else:
                shard_count = 3  # default per Requirement 4.2

        components.append(
            ComponentModel(
                name=component_name,
                replicas=replicas,
                resources=resources,
                storage=storage,
                rts_count=rts_count,
                heap_max=heap_max,
                hpa_max_replicas=hpa_max_replicas,
                engines=[],  # Populated by extract_engines (task 5.2)
                shard_count=shard_count,
            )
        )
        logger.debug(
            "Extracted component '%s': replicas=%d, storage=%s",
            component_name,
            replicas,
            storage,
        )

    return components


def extract_datasources(webapp_spec: dict[str, Any]) -> list[DatasourceModel]:
    """Extract database datasource configurations from webapp spec.

    Reads the primary datasource and any business datasources from the
    ``dataSources`` section of the webapp spec. For each datasource, the
    short name is extracted from the JNDI name (the portion after the last
    ``/`` character) and the database type is determined from the JDBC URL
    using ``extract_db_type``.

    Args:
        webapp_spec: The webapp section of the parsed site YAML
            (e.g. ``data["spec"]["webapp"]``).

    Returns:
        A list of DatasourceModel instances. Returns an empty list if
        ``dataSources`` is absent or empty.
    """
    data_sources = webapp_spec.get("dataSources")
    if not data_sources:
        return []

    datasources: list[DatasourceModel] = []

    # Extract primary datasource
    primary = data_sources.get("primary")
    if primary:
        jndi_name: str = primary.get("name", "")
        short_name = jndi_name.rsplit("/", 1)[-1] if jndi_name else ""
        jdbc_url: str = primary.get("url", "")
        db_type = extract_db_type(jdbc_url)
        datasources.append(
            DatasourceModel(
                name=short_name,
                db_type=db_type,
                is_primary=True,
            )
        )
        logger.debug("Extracted primary datasource: name='%s', db_type='%s'", short_name, db_type)

    # Extract business datasources
    business = data_sources.get("business")
    if business and isinstance(business, list):
        for ds in business:
            jndi_name = ds.get("name", "")
            short_name = jndi_name.rsplit("/", 1)[-1] if jndi_name else ""
            jdbc_url = ds.get("url", "")
            db_type = extract_db_type(jdbc_url)
            datasources.append(
                DatasourceModel(
                    name=short_name,
                    db_type=db_type,
                    is_primary=False,
                )
            )
            logger.debug("Extracted business datasource: name='%s', db_type='%s'", short_name, db_type)

    return datasources
