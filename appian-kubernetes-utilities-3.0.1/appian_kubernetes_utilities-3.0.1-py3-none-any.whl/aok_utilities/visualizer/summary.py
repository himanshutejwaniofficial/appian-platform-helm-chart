"""Resource summary table output.

Prints a tabular resource summary to stdout showing per-component
and site-total CPU, memory, and storage allocations.
"""

from aok_utilities.visualizer.parser import SiteModel


def print_resource_summary(site: SiteModel) -> None:
    """Print a tabular resource summary to stdout.

    Displays per-component and site-total CPU, memory, and RWO storage
    allocations in a formatted table. Components are shown in COMPONENT_LIST
    order, only those present (replicas > 0). Includes a TOTAL row and
    explanatory footer notes.

    Args:
        site: The fully-parsed and calculated site model.
    """
    # Column widths
    w_comp = 20
    w_repl = 10
    w_cpu = 12
    w_mem = 14
    w_stor = 16

    # Total line width: columns + separators (6 separators of " | " = 18 chars)
    total_width = w_comp + w_repl + w_cpu + w_cpu + w_mem + w_mem + w_stor + 18

    # Header
    print("\n" + "=" * total_width)
    print(f"{'RESOURCE SUMMARY':^{total_width}}")
    print("=" * total_width)

    header_str = (
        f"{'Component':<{w_comp}} | "
        f"{'Replicas':<{w_repl}} | "
        f"{'CPU Req':<{w_cpu}} | "
        f"{'CPU Lim':<{w_cpu}} | "
        f"{'Mem Req (Gi)':<{w_mem}} | "
        f"{'Mem Lim (Gi)':<{w_mem}} | "
        f"{'RWO Storage (Gi)':<{w_stor}}"
    )
    print(header_str)
    print("-" * total_width)

    # Component rows — COMPONENT_LIST order, only those present
    for component in site.components:
        if component.replicas <= 0:
            continue

        # Format replicas — show shard count for serviceManager when > 0
        if component.name == "serviceManager" and component.shard_count > 0:
            replicas_str = f"{component.replicas} ({component.shard_count})"
        else:
            replicas_str = str(component.replicas)

        # Get component totals
        totals = site.component_totals[component.name]

        # Format RWO storage — dash if 0.0 (no volumeClaimTemplateSpec)
        if totals.rwo_storage == 0.0:
            storage_str = "-"
        else:
            storage_str = f"{totals.rwo_storage:.3f}"

        print(
            f"{component.name:<{w_comp}} | "
            f"{replicas_str:<{w_repl}} | "
            f"{totals.cpu_request:<{w_cpu}.3f} | "
            f"{totals.cpu_limit:<{w_cpu}.3f} | "
            f"{totals.mem_request:<{w_mem}.3f} | "
            f"{totals.mem_limit:<{w_mem}.3f} | "
            f"{storage_str:<{w_stor}}"
        )

    # Separator before TOTAL
    print("-" * total_width)

    # TOTAL row from site_totals
    totals = site.site_totals
    if totals.rwo_storage == 0.0:
        total_storage_str = "-"
    else:
        total_storage_str = f"{totals.rwo_storage:.3f}"

    print(
        f"{'TOTAL':<{w_comp}} | "
        f"{'':<{w_repl}} | "
        f"{totals.cpu_request:<{w_cpu}.3f} | "
        f"{totals.cpu_limit:<{w_cpu}.3f} | "
        f"{totals.mem_request:<{w_mem}.3f} | "
        f"{totals.mem_limit:<{w_mem}.3f} | "
        f"{total_storage_str:<{w_stor}}"
    )
    print("=" * total_width)

    # Footer notes
    print("* CPU and Memory values represent the total resources for the component across all replicas.")
    print("* For Service Manager, value in brackets indicates shard count.")
    print("* RWO Storage excludes shared (RWX) volumes which cannot be determined from the site YAML alone.")
    print()
