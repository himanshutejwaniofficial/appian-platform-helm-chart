"""Unit conversion functions for CPU and memory values.

Provides functions to normalise Kubernetes resource values to consistent
units: CPU to cores (float) and memory to GiB (float).
"""


def convert_memory(value: str | int | float) -> float:
    """Convert a Kubernetes memory value to gibibytes (GiB).

    Handles the following suffixes:
        - "Mi" (mebibytes): divide numeric portion by 1000
        - "Gi" (gibibytes): return numeric portion unchanged
        - "M" (megabytes): multiply by (1000 / 1024³)
        - "G" (gigabytes): multiply by (1000³ / 1024³)

    Empty strings and the string "0" return 0.0.

    Args:
        value: A memory value string (e.g. "512Mi", "2Gi", "1000M", "1G"),
            or a numeric type that will be coerced to string before parsing.

    Returns:
        The memory value expressed in gibibytes as a float.

    Raises:
        ValueError: If the suffix is unrecognised or the numeric prefix is invalid.
    """
    memory_size = str(value)

    if not memory_size or memory_size == "0":
        return 0.0

    try:
        if memory_size.endswith("Mi"):
            return float(memory_size[:-2]) / 1000
        elif memory_size.endswith("Gi"):
            return float(memory_size[:-2])
        elif memory_size.endswith("M"):
            return float(memory_size[:-1]) * (1000 / (1024**3))
        elif memory_size.endswith("G"):
            return float(memory_size[:-1]) * (1000**3 / 1024**3)
        else:
            raise ValueError(f"Invalid memory size format: {memory_size}")
    except ValueError as err:
        if "Invalid memory size format" in str(err):
            raise
        raise ValueError(f"Invalid memory size format: {memory_size}") from err


def convert_cpu(value: str | int | float) -> float:
    """Convert a Kubernetes CPU value to cores.

    Accepts millicore notation (e.g. "500m") or plain numeric strings/values
    (e.g. "2", "0.5", 1). Non-string inputs are coerced to string before parsing.

    Args:
        value: CPU value as a string with optional "m" suffix, or a numeric type.

    Returns:
        The CPU value in cores as a float.

    Raises:
        ValueError: If the value cannot be parsed as a valid CPU specification.
    """
    cpu_str = str(value)
    try:
        if cpu_str.endswith("m"):
            return float(cpu_str[:-1]) / 1000
        return float(cpu_str)
    except ValueError:
        raise ValueError(f"Invalid CPU size format: {cpu_str}")
