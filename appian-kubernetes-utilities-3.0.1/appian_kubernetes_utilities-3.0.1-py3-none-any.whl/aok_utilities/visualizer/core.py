"""Orchestrator for the Config Visualizer pipeline.

Coordinates the parse → extract → calculate → check_graphviz → render → summary
pipeline for the `aok visualize` subcommand.
"""

import logging
import shutil
from pathlib import Path

from aok_utilities.common.exceptions import DependencyError
from aok_utilities.visualizer.calculator import (
    calculate_component_totals,
    calculate_site_totals,
    calculate_sm_totals,
)
from aok_utilities.visualizer.parser import (
    ComponentModel,
    ResourceTotals,
    SiteModel,
    detect_ha,
    extract_components,
    extract_datasources,
    extract_engines,
    extract_ingress,
    extract_smtp,
    parse_site_yaml,
)
from aok_utilities.visualizer.renderer import render_diagram
from aok_utilities.visualizer.summary import print_resource_summary

logger = logging.getLogger(__name__)


def check_graphviz() -> None:
    """Verify Graphviz is installed before attempting diagram generation.

    Raises:
        DependencyError: If the ``dot`` binary is not found on the system PATH,
            with platform-specific installation instructions.
    """
    if shutil.which("dot") is None:
        raise DependencyError(
            dependency="Graphviz",
            instructions=(
                "Install Graphviz to generate diagrams:\n"
                "  macOS:         brew install graphviz\n"
                "  Windows:       choco install graphviz  (or)  winget install graphviz\n"
                "  Debian/Ubuntu: sudo apt install graphviz"
            ),
        )


def visualize(input_path: Path, output_path: Path) -> None:
    """Orchestrate the full visualizer pipeline.

    Parses the site YAML, extracts all components and metadata, calculates
    resource totals, checks for Graphviz, renders the diagram, and prints
    the resource summary.

    Args:
        input_path: Path to the Appian site YAML file.
        output_path: Output path for the generated PNG (without extension).

    Raises:
        ConfigFileError: If the input file cannot be read or parsed.
        ValidationError: If the site YAML fails schema validation.
        DependencyError: If Graphviz is not installed.
        OutputDirectoryError: If the output directory does not exist.
    """
    # Step 1: Parse the site YAML
    logger.debug("Parsing site YAML: %s", input_path)
    data = parse_site_yaml(input_path)

    # Step 2: Extract spec and custom properties
    spec = data.get("spec", {})
    custom_props = spec.get("customProperties", {})

    # Step 3: Extract site metadata
    site_name = data["metadata"]["name"]
    site_version = spec["version"]
    site_url = spec["url"]

    webapp_spec = spec.get("webapp", {}) or {}
    static_url = webapp_spec.get("staticUrl", "")
    dynamic_url = webapp_spec.get("dynamicUrl", "")

    # Step 4: Extract components
    logger.debug("Extracting components")
    components = extract_components(spec, custom_props)

    # Step 5: For serviceManager, extract engines and merge into component
    sm_spec = spec.get("serviceManager", {}) or {}
    updated_components: list[ComponentModel] = []

    for comp in components:
        if comp.name == "serviceManager" and comp.replicas > 0:
            engines, shard_count = extract_engines(sm_spec)
            # Create a new ComponentModel with engines populated
            updated_comp = ComponentModel(
                name=comp.name,
                replicas=comp.replicas,
                resources=comp.resources,
                storage=comp.storage,
                rts_count=comp.rts_count,
                heap_max=comp.heap_max,
                hpa_max_replicas=comp.hpa_max_replicas,
                engines=engines,
                shard_count=shard_count,
            )
            updated_components.append(updated_comp)
        else:
            updated_components.append(comp)

    components = updated_components

    # Step 6: Extract datasources
    logger.debug("Extracting datasources")
    datasources = extract_datasources(webapp_spec)

    # Step 7: Extract SMTP
    logger.debug("Extracting SMTP configuration")
    smtp = extract_smtp(custom_props)

    # Step 8: Extract ingress
    logger.debug("Extracting ingress configuration")
    ingress = extract_ingress(spec)

    # Step 9: Detect HA
    logger.debug("Detecting HA configuration")
    ha = detect_ha(spec)

    # Step 10: Extract health check claim and service type
    health_check_claim = webapp_spec.get("healthCheckExistingClaim", "") or ""
    service_spec = spec.get("service", {}) or {}
    service_type = service_spec.get("type", "ClusterIP")

    # Step 11: Calculate totals
    logger.debug("Calculating resource totals")
    component_totals: dict[str, ResourceTotals] = {}

    for comp in components:
        if comp.name == "serviceManager":
            component_totals[comp.name] = calculate_sm_totals(comp)
        else:
            component_totals[comp.name] = calculate_component_totals(comp)

    site_totals = calculate_site_totals(component_totals)

    # Step 12: Build the SiteModel
    site = SiteModel(
        name=site_name,
        version=site_version,
        url=site_url,
        static_url=static_url,
        dynamic_url=dynamic_url,
        components=components,
        datasources=datasources,
        smtp=smtp,
        ingress=ingress,
        ha=ha,
        health_check_claim=health_check_claim,
        service_type=service_type,
        component_totals=component_totals,
        site_totals=site_totals,
    )

    # Step 13: Check Graphviz dependency (after parsing, before rendering)
    logger.debug("Checking Graphviz availability")
    check_graphviz()

    # Step 14: Render the diagram
    logger.debug("Rendering diagram to %s", output_path)
    render_diagram(site, output_path)

    # Step 15: Print the resource summary
    print_resource_summary(site)
