"""Config Visualizer subcommand for aok_utilities.

Provides the `aok visualize` CLI subcommand that reads an Appian site YAML
(Kubernetes Custom Resource) and produces a PNG architecture diagram and a
text-based resource summary table.
"""

import logging
from pathlib import Path

import typer

from aok_utilities.common.exceptions import AokError

app = typer.Typer(help="Visualize an AoK site YAML as a diagram and resource summary.")


@app.callback(invoke_without_command=True)
def visualize_command(
    input: Path = typer.Option(
        ...,
        "-i",
        "--input",
        help="Path to Appian site YAML file",
    ),
    output: Path = typer.Option(
        Path("./appian_site_visualisation"),
        "-o",
        "--output",
        help="Output path for the generated PNG (without extension)",
    ),
    debug: bool = typer.Option(
        False,
        "-d",
        "--debug",
        help="Enable verbose diagnostic output",
    ),
) -> None:
    """Visualize an Appian site YAML as a PNG diagram and resource summary."""
    # Configure logging level
    if debug:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(name)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    # Strip .png extension if provided (diagrams library adds it automatically)
    if output.suffix.lower() == ".png":
        output = output.with_suffix("")

    # Validate output directory exists
    output_dir = output.parent
    if not output_dir.exists():
        typer.echo(f"Error: Output directory '{output_dir}' does not exist.", err=True)
        raise typer.Exit(code=1)

    # Run the pipeline
    try:
        from aok_utilities.visualizer.core import visualize

        visualize(input_path=input, output_path=output)
    except AokError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(code=1)
