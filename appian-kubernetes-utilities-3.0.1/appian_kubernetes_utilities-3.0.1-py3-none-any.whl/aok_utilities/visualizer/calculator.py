"""Resource total calculation logic.

Computes per-component and site-wide aggregate resource totals from
parsed component and engine data.
"""

from aok_utilities.visualizer.converter import convert_memory
from aok_utilities.visualizer.parser import ComponentModel, ResourceTotals


def calculate_component_totals(component: ComponentModel) -> ResourceTotals:
    """Calculate total resources for a non-serviceManager component.

    Multiplies per-pod resources by replica count. Also calculates RWO storage
    as storage_size_in_gib × replicas. Rounds all values to 3 decimal places.
    If replicas is 0 or None, defaults to 1 for the calculation (per Req 7.3).

    Args:
        component: The parsed component model with per-pod resources and storage.

    Returns:
        A ResourceTotals with aggregated values rounded to 3 decimal places.
    """
    replicas = component.replicas if component.replicas else 1

    cpu_request = round(component.resources.cpu_request * replicas, 3)
    cpu_limit = round(component.resources.cpu_limit * replicas, 3)
    mem_request = round(component.resources.mem_request * replicas, 3)
    mem_limit = round(component.resources.mem_limit * replicas, 3)

    # Calculate RWO storage
    rwo_storage = 0.0
    if component.storage is not None:
        storage_gib = convert_memory(component.storage.size)
        rwo_storage = round(storage_gib * replicas, 3)

    return ResourceTotals(
        cpu_request=cpu_request,
        cpu_limit=cpu_limit,
        mem_request=mem_request,
        mem_limit=mem_limit,
        rwo_storage=rwo_storage,
    )


def calculate_sm_totals(component: ComponentModel) -> ResourceTotals:
    """Calculate total resources for the serviceManager component.

    Sums all engine resource values and multiplies by replica count.
    RWO storage is calculated as per-engine PVC size × engine count × replicas,
    because each SM replica provisions one PVC per engine.
    Rounds to 3dp. If replicas is 0 or None, defaults to 1.

    Args:
        component: The serviceManager ComponentModel with engines populated.

    Returns:
        A ResourceTotals with aggregated values rounded to 3 decimal places.
    """
    replicas = component.replicas if component.replicas else 1

    # Sum resource values across all engines
    total_cpu_request = 0.0
    total_cpu_limit = 0.0
    total_mem_request = 0.0
    total_mem_limit = 0.0

    for engine in component.engines:
        total_cpu_request += engine.resources.cpu_request
        total_cpu_limit += engine.resources.cpu_limit
        total_mem_request += engine.resources.mem_request
        total_mem_limit += engine.resources.mem_limit

    # Multiply sums by replica count and round
    cpu_request = round(total_cpu_request * replicas, 3)
    cpu_limit = round(total_cpu_limit * replicas, 3)
    mem_request = round(total_mem_request * replicas, 3)
    mem_limit = round(total_mem_limit * replicas, 3)

    # Calculate RWO storage: per-engine PVC size × engine count × replicas
    # Each SM replica provisions one PVC per engine
    rwo_storage = 0.0
    if component.storage is not None:
        storage_gib = convert_memory(component.storage.size)
        engine_count = len(component.engines)
        rwo_storage = round(storage_gib * engine_count * replicas, 3)

    return ResourceTotals(
        cpu_request=cpu_request,
        cpu_limit=cpu_limit,
        mem_request=mem_request,
        mem_limit=mem_limit,
        rwo_storage=rwo_storage,
    )


def calculate_site_totals(component_totals: dict[str, ResourceTotals]) -> ResourceTotals:
    """Calculate site-wide totals by summing all component totals.

    Sums cpu_request, cpu_limit, mem_request, mem_limit, and rwo_storage
    across all components. Rounds to 3dp.

    Args:
        component_totals: A dictionary mapping component names to their
            calculated ResourceTotals.

    Returns:
        A ResourceTotals representing the site-wide aggregate, rounded
        to 3 decimal places.
    """
    total_cpu_request = 0.0
    total_cpu_limit = 0.0
    total_mem_request = 0.0
    total_mem_limit = 0.0
    total_rwo_storage = 0.0

    for totals in component_totals.values():
        total_cpu_request += totals.cpu_request
        total_cpu_limit += totals.cpu_limit
        total_mem_request += totals.mem_request
        total_mem_limit += totals.mem_limit
        total_rwo_storage += totals.rwo_storage

    return ResourceTotals(
        cpu_request=round(total_cpu_request, 3),
        cpu_limit=round(total_cpu_limit, 3),
        mem_request=round(total_mem_request, 3),
        mem_limit=round(total_mem_limit, 3),
        rwo_storage=round(total_rwo_storage, 3),
    )
