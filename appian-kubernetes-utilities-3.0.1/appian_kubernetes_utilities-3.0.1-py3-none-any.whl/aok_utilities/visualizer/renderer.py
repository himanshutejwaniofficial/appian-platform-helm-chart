"""Diagram generator using the diagrams Python library.

Produces a PNG architecture diagram from a parsed SiteModel, showing
pods, PVCs, services, ingress, databases, and SMTP connectivity.
"""

from __future__ import annotations

import logging
from pathlib import Path

from diagrams import Cluster, Diagram, Edge, Node
from diagrams.aws.network import ALB
from diagrams.azure.network import ApplicationGateway
from diagrams.generic.compute import Rack
from diagrams.generic.database import SQL
from diagrams.k8s.compute import Pod
from diagrams.k8s.network import SVC
from diagrams.k8s.storage import PVC
from diagrams.onprem.client import Users
from diagrams.onprem.database import MariaDB, Mssql, MySQL, Oracle, PostgreSQL
from diagrams.onprem.network import Internet, Nginx

from aok_utilities.common.exceptions import OutputDirectoryError
from aok_utilities.visualizer.parser import (
    ComponentModel,
    IngressModel,
    SiteModel,
)

logger = logging.getLogger(__name__)


def _get_db_node(db_type: str, label: str) -> Node:
    """Return the correct database diagram node for a given database type.

    Args:
        db_type: The database type string (e.g. "mariadb", "postgresql").
        label: The label text for the node.

    Returns:
        A diagrams Node with the appropriate database icon.
    """
    if db_type == "mariadb":
        return MariaDB("MariaDB")
    elif db_type == "mysql":
        return MySQL("MySQL")
    elif db_type == "postgresql":
        return PostgreSQL("PostgreSQL")
    elif db_type == "oracle":
        return Oracle("Oracle")
    elif db_type == "sqlserver":
        return Mssql("SQL Server")
    elif db_type == "db2":
        return SQL("DB2")
    else:
        return SQL(db_type)


def _get_ingress_node(ingress: IngressModel) -> Node:
    """Return the correct ingress diagram node based on ingress configuration.

    Args:
        ingress: The parsed ingress model containing enabled flag and class.

    Returns:
        A diagrams Node with the appropriate ingress icon and label.
    """
    if not ingress.enabled:
        return Internet("Ingress Configuration Unknown")

    match ingress.ingress_class:
        case "alb":
            return ALB("AWS Application Load Balancer")
        case "azure/application-gateway":
            return ApplicationGateway("Azure Application Gateway")
        case "nginx":
            return Nginx("Nginx")
        case _:
            return Internet(f"Ingress: {ingress.ingress_class}")


def _get_component(site: SiteModel, name: str) -> ComponentModel | None:
    """Retrieve a component from the site model by name.

    Args:
        site: The complete site model.
        name: The component name to look up.

    Returns:
        The ComponentModel if found, otherwise None.
    """
    for comp in site.components:
        if comp.name == name:
            return comp
    return None


def _format_resource_label(cpu_req: float, cpu_lim: float, mem_req: float, mem_lim: float) -> str:
    """Format a resource summary label for a cluster.

    Args:
        cpu_req: Total CPU requests in cores.
        cpu_lim: Total CPU limits in cores.
        mem_req: Total memory requests in GiB.
        mem_lim: Total memory limits in GiB.

    Returns:
        A two-line formatted resource summary string.
    """
    return f"Total cpu {cpu_req} - {cpu_lim} cores\nTotal ram {mem_req} - {mem_lim} Gi"


def render_diagram(site: SiteModel, output_path: Path) -> None:
    """Render a PNG architecture diagram from a parsed SiteModel.

    Produces a complete Appian site architecture diagram showing pods, PVCs,
    services, ingress, databases, and SMTP connectivity. The output PNG is
    written to the specified path (the ``diagrams`` library appends ``.png``).

    Args:
        site: The fully-parsed and calculated site model.
        output_path: The filesystem path (without extension) for the output PNG.

    Raises:
        OutputDirectoryError: If the output directory does not exist.
    """
    # Validate output directory exists
    output_dir = output_path.parent
    if not output_dir.exists():
        raise OutputDirectoryError(
            output_dir,
            "output directory does not exist",
        )

    logger.debug("Rendering diagram to %s", output_path)

    # Collect node lists for connectivity edges later
    zks: list[Node] = []
    kafkas: list[Node] = []
    sms: list[Node] = []
    sss: list[Node] = []
    dss: list[Node] = []
    webapps: list[Node] = []
    httpds: list[Node] = []

    # Site-level resource label
    site_totals = site.site_totals
    site_rsc_label = (
        f"Total cpu (cores) {site_totals.cpu_request} requests - {site_totals.cpu_limit} limits\n"
        f"Total ram (Gi) {site_totals.mem_request} requests - {site_totals.mem_limit} limits"
    )

    site_label = f"{site.name} ({site.version})"

    with Diagram(
        name="Appian Site Visualisation",
        filename=str(output_path),
        show=False,
        direction="TB",
    ):
        # Outer cluster: Appian site
        with Cluster(f"Appian\n{site_label}\n\n{site_rsc_label}"):
            # --- Zookeeper ---
            zk_comp = _get_component(site, "zookeeper")
            if zk_comp and zk_comp.replicas > 0:
                zk_totals = site.component_totals.get("zookeeper")
                if zk_totals:
                    rsc_label = _format_resource_label(
                        zk_totals.cpu_request,
                        zk_totals.cpu_limit,
                        zk_totals.mem_request,
                        zk_totals.mem_limit,
                    )
                else:
                    rsc_label = ""
                with Cluster(f"Zookeeper\n\n{rsc_label}"):
                    for i in range(zk_comp.replicas):
                        pod = Pod(
                            f"zookeeper-{i}\n"
                            f"cpu {zk_comp.resources.cpu_request} - {zk_comp.resources.cpu_limit}\n"
                            f"ram {zk_comp.resources.mem_request} - {zk_comp.resources.mem_limit}"
                        )
                        zks.append(pod)
                        if zk_comp.storage:
                            pvc = PVC(f"{zk_comp.storage.storage_class} {zk_comp.storage.size}")
                            zks[-1] - Edge(style="dashed") - pvc

            # --- Kafka ---
            kafka_comp = _get_component(site, "kafka")
            if kafka_comp and kafka_comp.replicas > 0:
                kafka_totals = site.component_totals.get("kafka")
                if kafka_totals:
                    rsc_label = _format_resource_label(
                        kafka_totals.cpu_request,
                        kafka_totals.cpu_limit,
                        kafka_totals.mem_request,
                        kafka_totals.mem_limit,
                    )
                else:
                    rsc_label = ""
                with Cluster(f"Kafka\n\n{rsc_label}"):
                    for i in range(kafka_comp.replicas):
                        pod = Pod(
                            f"kafka-{i}\n"
                            f"cpu {kafka_comp.resources.cpu_request} - {kafka_comp.resources.cpu_limit}\n"
                            f"ram {kafka_comp.resources.mem_request} - {kafka_comp.resources.mem_limit}"
                        )
                        kafkas.append(pod)
                        if kafka_comp.storage:
                            pvc = PVC(f"{kafka_comp.storage.storage_class} {kafka_comp.storage.size}")
                            kafkas[-1] - Edge(style="dashed") - pvc

            # --- Service Manager ---
            sm_comp = _get_component(site, "serviceManager")
            if sm_comp and sm_comp.replicas > 0:
                sm_totals = site.component_totals.get("serviceManager")
                if sm_totals:
                    rsc_label = _format_resource_label(
                        sm_totals.cpu_request,
                        sm_totals.cpu_limit,
                        sm_totals.mem_request,
                        sm_totals.mem_limit,
                    )
                else:
                    rsc_label = ""
                with Cluster(f"Service Manager\n\n{rsc_label}"):
                    replicas = sm_comp.replicas
                    engines = sm_comp.engines
                    # Track the first engine pod index in each replica cluster
                    # for invisible edge stacking
                    replica_first_indices: list[int] = []

                    for i in range(replicas):
                        with Cluster(f"{i}"):
                            replica_first_indices.append(len(sms))
                            for engine in engines:
                                pod = Pod(
                                    f"{engine.name}-{i}\n"
                                    f"cpu {engine.resources.cpu_request} - {engine.resources.cpu_limit}\n"
                                    f"ram {engine.resources.mem_request} - {engine.resources.mem_limit}"
                                )
                                sms.append(pod)
                            # PVC per replica showing engine count
                            if sm_comp.storage:
                                pvc = PVC(f"{sm_comp.storage.storage_class} {sm_comp.storage.size} x {len(engines)}")
                                # PVC is part of replica cluster (no edge to specific pod)

                    # Invisible edges between first engine pod of adjacent replica clusters
                    if replicas > 1:
                        for r in range(replicas - 1):
                            sms[replica_first_indices[r]] - Edge(style="invis") - sms[replica_first_indices[r + 1]]

            # --- Search Server ---
            ss_comp = _get_component(site, "searchServer")
            if ss_comp and ss_comp.replicas > 0:
                ss_totals = site.component_totals.get("searchServer")
                if ss_totals:
                    rsc_label = _format_resource_label(
                        ss_totals.cpu_request,
                        ss_totals.cpu_limit,
                        ss_totals.mem_request,
                        ss_totals.mem_limit,
                    )
                else:
                    rsc_label = ""
                with Cluster(f"Search Server\n\n{rsc_label}"):
                    for i in range(ss_comp.replicas):
                        pod = Pod(
                            f"search-server-{i}\n"
                            f"cpu {ss_comp.resources.cpu_request} - {ss_comp.resources.cpu_limit}\n"
                            f"ram {ss_comp.resources.mem_request} - {ss_comp.resources.mem_limit}"
                        )
                        sss.append(pod)
                        if ss_comp.storage:
                            pvc = PVC(f"{ss_comp.storage.storage_class} {ss_comp.storage.size}")
                            sss[-1] - Edge(style="dashed") - pvc

            # --- Data Server ---
            ds_comp = _get_component(site, "dataServer")
            if ds_comp and ds_comp.replicas > 0:
                ds_totals = site.component_totals.get("dataServer")
                if ds_totals:
                    rsc_label = _format_resource_label(
                        ds_totals.cpu_request,
                        ds_totals.cpu_limit,
                        ds_totals.mem_request,
                        ds_totals.mem_limit,
                    )
                else:
                    rsc_label = ""
                with Cluster(f"Data Server\n\n{rsc_label}"):
                    for i in range(ds_comp.replicas):
                        pod = Pod(
                            f"data-server-{i}\n"
                            f"cpu {ds_comp.resources.cpu_request} - {ds_comp.resources.cpu_limit}\n"
                            f"ram {ds_comp.resources.mem_request} - {ds_comp.resources.mem_limit}"
                        )
                        dss.append(pod)
                        if ds_comp.storage:
                            pvc = PVC(f"{ds_comp.storage.storage_class} {ds_comp.storage.size}")
                            dss[-1] - Edge(style="dashed") - pvc

            # --- Webapp ---
            webapp_comp = _get_component(site, "webapp")
            if webapp_comp and webapp_comp.replicas > 0:
                webapp_totals = site.component_totals.get("webapp")
                if webapp_totals:
                    rsc_label = _format_resource_label(
                        webapp_totals.cpu_request,
                        webapp_totals.cpu_limit,
                        webapp_totals.mem_request,
                        webapp_totals.mem_limit,
                    )
                else:
                    rsc_label = ""
                # Include max heap in cluster label
                extras_label = f"Max heap {webapp_comp.heap_max} (per pod)" if webapp_comp.heap_max else ""
                cluster_label = f"Webapp\n\n{rsc_label}"
                if extras_label:
                    cluster_label += f"\n\n{extras_label}"
                with Cluster(cluster_label):
                    for i in range(webapp_comp.replicas):
                        pod = Pod(
                            f"webapp-{i}\n"
                            f"cpu {webapp_comp.resources.cpu_request} - {webapp_comp.resources.cpu_limit}\n"
                            f"ram {webapp_comp.resources.mem_request} - {webapp_comp.resources.mem_limit}"
                        )
                        webapps.append(pod)
                        if webapp_comp.storage:
                            pvc = PVC(f"{webapp_comp.storage.storage_class} {webapp_comp.storage.size}")
                            webapps[-1] - Edge(style="dashed") - pvc

            # --- httpd ---
            httpd_comp = _get_component(site, "httpd")
            if httpd_comp and httpd_comp.replicas > 0:
                httpd_totals = site.component_totals.get("httpd")
                if httpd_totals:
                    rsc_label = _format_resource_label(
                        httpd_totals.cpu_request,
                        httpd_totals.cpu_limit,
                        httpd_totals.mem_request,
                        httpd_totals.mem_limit,
                    )
                else:
                    rsc_label = ""
                with Cluster(f"httpd\n\n{rsc_label}"):
                    # Determine if these are HPA pods or regular pods
                    if httpd_comp.hpa_max_replicas and httpd_comp.hpa_max_replicas > 0:
                        # HPA pods: use -hpa-autoscaler suffix
                        for i in range(httpd_comp.replicas):
                            pod = Pod(
                                f"httpd-{i}-hpa-autoscaler\n"
                                f"cpu {httpd_comp.resources.cpu_request} - {httpd_comp.resources.cpu_limit}\n"
                                f"ram {httpd_comp.resources.mem_request} - {httpd_comp.resources.mem_limit}"
                            )
                            httpds.append(pod)
                    else:
                        # Regular pods
                        for i in range(httpd_comp.replicas):
                            pod = Pod(
                                f"httpd-{i}\n"
                                f"cpu {httpd_comp.resources.cpu_request} - {httpd_comp.resources.cpu_limit}\n"
                                f"ram {httpd_comp.resources.mem_request} - {httpd_comp.resources.mem_limit}"
                            )
                            httpds.append(pod)

            # --- Shared Storage ---
            if site.health_check_claim:
                PVC(f"Shared Logs\n{site.health_check_claim}")

            if site.ha.enabled:
                PVC(f"HA Data\n{site.ha.claim_name}")

            # --- K8s Service node ---
            svc = SVC(f"{site.service_type}")

            # --- Inter-component connectivity ---
            if kafkas and zks:
                kafkas[0] >> zks[0]
            if sms and zks:
                sms[0] >> zks[0]
            if sms and kafkas:
                sms[0] >> kafkas[0]
            if dss and zks:
                dss[0] >> zks[0]
            if dss and kafkas:
                dss[0] >> kafkas[0]
            if webapps and zks:
                webapps[0] >> zks[0]
            if webapps and kafkas:
                webapps[0] >> kafkas[0]
            if webapps and sms:
                webapps[0] >> sms[0]
            if webapps and sss:
                webapps[0] >> sss[0]
            if webapps and dss:
                webapps[0] >> dss[0]

            # httpd/webapp/service connectivity
            if httpds:
                httpds[0] >> webapps[0]
                svc >> httpds[0]
            elif webapps:
                svc >> webapps[0]

        # --- External nodes (outside the Appian cluster) ---

        # Databases
        for ds in site.datasources:
            db_node = _get_db_node(ds.db_type, ds.name)
            if webapps:
                db_node - Edge(label=f"jdbc ({ds.name})") - webapps[0]

        # SMTP
        if site.smtp and webapps:
            smtp_node = Rack(f"SMTP Server\n{site.smtp.host}")
            webapps[0] - Edge(label=site.smtp.protocol) - smtp_node

        # Ingress
        lb = _get_ingress_node(site.ingress)
        lb >> svc

        # Users
        url_label = f"{site.url}\n{site.static_url}\n{site.dynamic_url}"
        usrs = Users()
        usrs >> Edge(label=url_label) >> lb

    logger.debug("Diagram rendered successfully to %s", output_path)
