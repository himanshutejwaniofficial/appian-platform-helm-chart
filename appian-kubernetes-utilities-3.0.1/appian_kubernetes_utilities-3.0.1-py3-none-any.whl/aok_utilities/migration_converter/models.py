"""Data models for the migration converter pipeline.

Defines the intermediate representations used between the parser, validator,
and emitter stages of the migration conversion process.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class DataSource:
    """Represents a single JDBC data source extracted from the draft site YAML."""

    name: str
    driver_class_name: str
    url: str  # preserves original quoting
    username: str
    password_secret_key_ref: str
    factory: str
    type: str
    attributes: dict[str, str]
    db_type: str  # extracted from URL (mysql, mysql:aws, postgresql, etc.)


@dataclass(frozen=True)
class SmtpConfig:
    """SMTP configuration extracted from custom properties."""

    sender_address: str | None
    sender_domain: str | None
    host: str | None
    auth: bool | None
    user: str | None
    protocol: str | None
    starttls_enabled: bool | None
    starttls_required: bool | None
    mail_scheme: str | None
    mail_server_and_port: str | None


@dataclass(frozen=True)
class ParsedSite:
    """Structured intermediate representation of a parsed draft site YAML."""

    url: str
    version: str
    year: int
    quarter: int
    high_availability: bool
    custom_properties: dict[str, str]  # ALL raw custom properties from input
    additional_custom_properties: dict[str, str]  # remaining after extraction
    enforced_properties: dict[str, str | int]  # mapped to Helm keys
    smtp: SmtpConfig | None
    component_replicas: dict[str, int]  # component_name → count
    service_manager_replicas: int
    engine_overrides: dict[str, int]  # engine_name → replica count
    analytics_exec_shard_count: int | None
    data_sources: list[DataSource]
    static_url: str | None
    dynamic_url: str | None
    application_context: str
    metrics_auth_token: str | None
    raw_data_sources_yaml: Any = field(default=None)  # Preserved ruamel.yaml CommentedMap from input


@dataclass(frozen=True)
class ConversionResult:
    """Result of the migration conversion pipeline.

    Contains the structured Helm values dict, the raw YAML output string,
    and any validation warnings accumulated during processing.
    """

    helm_values: dict[str, Any]  # structured dict matching Helm values schema
    warnings: list[str]
    yaml_output: str  # complete YAML string ready to write to disk
