"""Validator module for the migration converter pipeline.

Applies business rules to parsed site data and accumulates
human-readable warning strings for non-standard, deprecated,
or potentially problematic configurations. All checks execute
independently — every applicable warning is collected in a
single pass.
"""

from __future__ import annotations

import logging

from aok_utilities.migration_converter.models import ParsedSite

logger = logging.getLogger(__name__)

# Components checked for replica count deviations (Req 2.5, 2.6).
# serviceManager and webapp have their own rules (Req 2.7, 2.9).
_REPLICA_CHECK_COMPONENTS: list[str] = [
    "zookeeper",
    "kafka",
    "searchServer",
    "dataServer",
]

# JDBC driver types that are not shipped with the platform (Req 2.11).
_UNSHIPPED_DRIVER_TYPES: set[str] = {"mysql", "mysql:aws", "db2"}


def validate(site: ParsedSite) -> list[str]:
    """Run all validation checks against the parsed site data.

    All checks execute independently; warnings accumulate.

    Args:
        site: The parsed site representation.

    Returns:
        List of human-readable warning strings.
    """
    warnings: list[str] = []

    _check_shard_count(site, warnings)
    _check_max_exec_engine_load_metric(site, warnings)
    _check_removed_properties(site, warnings)
    _check_component_replica_counts(site, warnings)
    _check_service_manager_replicas(site, warnings)
    _check_engine_override_replicas(site, warnings)
    _check_webapp_replicas(site, warnings)
    _check_application_context(site, warnings)
    _check_jdbc_driver_types(site, warnings)
    _check_static_data_source_factory(warnings)

    logger.debug("Validation produced %d warning(s)", len(warnings))
    return warnings


def _check_shard_count(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warning if analytics shard count exceeds 3 (Req 2.1)."""
    if site.analytics_exec_shard_count is not None and site.analytics_exec_shard_count > 3:
        warnings.append(
            f"Shard count is {site.analytics_exec_shard_count} (exceeds 3) — plan for additional cluster resources."
        )


def _check_max_exec_engine_load_metric(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warning if MAX_EXEC_ENGINE_LOAD_METRIC exceeds 2145 (Req 2.2)."""
    helm_key = "serviceManager.maxExecEngineLoadMetric"
    if helm_key in site.enforced_properties:
        value = site.enforced_properties[helm_key]
        try:
            int_value = int(value)
        except (ValueError, TypeError):
            return
        if int_value > 2145:
            warnings.append(
                f"MAX_EXEC_ENGINE_LOAD_METRIC is {int_value} which exceeds the maximum possible value of 2145."
            )


def _check_removed_properties(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warnings for removed/deprecated properties found in raw input (Req 2.3, 2.4)."""
    if "conf.search-server.user.appian.password" in site.custom_properties:
        warnings.append(
            "conf.search-server.user.appian.password is now managed by the Operator from v0.181.0 "
            "and has been removed from the output."
        )
    if "rts.queryMemoryLimits.circuitBreaker.threshold.bytes" in site.custom_properties:
        warnings.append(
            "rts.queryMemoryLimits.circuitBreaker.threshold.bytes is deprecated from Platform version 25.1 "
            "and has been removed from the output."
        )


def _check_component_replica_counts(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warnings for zookeeper, kafka, searchServer, dataServer replica deviations (Req 2.5, 2.6)."""
    expected = 3 if site.high_availability else 1
    for component in _REPLICA_CHECK_COMPONENTS:
        count = site.component_replicas.get(component, 0)
        if count != expected:
            warnings.append(
                f"{component} replica count is {count} (expected {expected} for "
                f"{'HA' if site.high_availability else 'non-HA'} mode)."
            )


def _check_service_manager_replicas(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warning if serviceManager replicas deviate from expected (Req 2.7)."""
    expected = 3 if site.high_availability else 1
    if site.service_manager_replicas != expected:
        warnings.append(
            f"serviceManager replica count is {site.service_manager_replicas} (expected {expected} for "
            f"{'HA' if site.high_availability else 'non-HA'} mode)."
        )


def _check_engine_override_replicas(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warnings for engine overrides with non-standard replica counts (Req 2.8)."""
    expected = 3 if site.high_availability else 1
    for engine_name, count in site.engine_overrides.items():
        if count != expected:
            warnings.append(
                f"Engine '{engine_name}' replica count is {count} (expected {expected} for "
                f"{'HA' if site.high_availability else 'non-HA'} mode)."
            )


def _check_webapp_replicas(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warning if webapp replicas are non-standard (Req 2.9).

    HA mode: warn if less than 3.
    Non-HA mode: warn if not exactly 1.
    """
    webapp_count = site.component_replicas.get("webapp", 0)
    if site.high_availability:
        if webapp_count < 3:
            warnings.append(f"webapp replica count is {webapp_count} (expected at least 3 for HA mode).")
    else:
        if webapp_count != 1:
            warnings.append(f"webapp replica count is {webapp_count} (expected 1 for non-HA mode).")


def _check_application_context(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warning if applicationContext is not 'suite' (Req 2.10)."""
    if site.application_context != "suite":
        warnings.append(
            f"applicationContext is '{site.application_context}' — a customised Application Context "
            "is not recommended by Appian."
        )


def _check_jdbc_driver_types(site: ParsedSite, warnings: list[str]) -> None:
    """Emit warnings for data sources using unshipped JDBC drivers (Req 2.11)."""
    for ds in site.data_sources:
        if ds.db_type in _UNSHIPPED_DRIVER_TYPES:
            warnings.append(
                f"Data source '{ds.name}' uses JDBC driver type '{ds.db_type}' which is not shipped "
                "with the platform and must be provisioned separately."
            )


def _check_static_data_source_factory(warnings: list[str]) -> None:
    """Always emit the data source factory warning (Req 2.12)."""
    warnings.append(
        "Data source factories must be changed to org.apache.tomcat.jdbc.pool.DataSourceFactory "
        "with passwords provided via passwordSecretKeyRef."
    )
