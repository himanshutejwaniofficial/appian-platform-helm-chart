"""Parser module for the migration converter pipeline.

Reads a Draft Site YAML file produced by Appian's Migration Tool and
extracts structured configuration data into a ParsedSite intermediate
representation for downstream validation and Helm values emission.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from aok_utilities.common.appian import COMPONENT_LIST, parse_version
from aok_utilities.common.db import extract_db_type
from aok_utilities.common.exceptions import ConfigFileError
from aok_utilities.common.yaml_utils import load_yaml_preserving_quotes
from aok_utilities.migration_converter.models import DataSource, ParsedSite, SmtpConfig

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Property registries
# ---------------------------------------------------------------------------

ENFORCED_PROPERTY_MAP: dict[str, tuple[str, type]] = {
    "conf.appserver.minHeapSize": ("webapp.minHeap", str),
    "conf.appserver.maxHeapSize": ("webapp.maxHeap", str),
    "ads.adb.systemConfig__.rts.threads": ("dataServer.rts.threads", int),
    "ads.adb.systemConfig__.rts.memory_limit": ("dataServer.rts.memoryLimit", str),
    "server.conf.processcommon.MAX_EXEC_ENGINE_LOAD_METRIC": ("serviceManager.maxExecEngineLoadMetric", int),
    "server.conf.processcommon.AUTODELETE_ARCHIVES_DELAY_DAYS": ("webapp.autodeleteArchivesDelayDays", int),
}

REMOVED_PROPERTIES: set[str] = {
    "conf.search-server.user.appian.password",
    "rts.queryMemoryLimits.circuitBreaker.threshold.bytes",
    "appian.feature.selfManagedMonitoring",
}

SMTP_PROPERTY_MAP: dict[str, tuple[str, type]] = {
    "conf.mailhandler.ntf_sndr_addr": ("senderAddress", str),
    "conf.mailhandler.email.domain": ("senderDomain", str),
    "conf.mailhandler.mail.smtp.host": ("host", str),
    "conf.mailhandler.mail.smtp.auth": ("auth", bool),
    "conf.mailhandler.mail.user": ("user", str),
    "conf.mailhandler.mail.transport.protocol": ("protocol", str),
    "conf.mailhandler.mail.smtp.starttls.enable": ("starttlsEnabled", bool),
    "conf.mailhandler.mail.smtp.starttls.required": ("starttlsRequired", bool),
    "conf.suite.MAIL_SCHEME": ("mailScheme", str),
    "conf.suite.MAIL_SERVER_AND_PORT": ("mailServerAndPort", str),
}


def parse_draft_site(path: Path) -> ParsedSite:
    """Load and parse the Draft Site YAML into a structured representation.

    Uses ruamel.yaml in round-trip mode (via load_yaml_preserving_quotes)
    to preserve string quoting metadata from the input file. Extracts
    top-level spec fields and delegates version parsing to parse_version().

    Args:
        path: Path to the input YAML file.

    Returns:
        ParsedSite dataclass with all extracted fields.

    Raises:
        ConfigFileError: File not found, not readable, or invalid YAML.
        ValueError: Version string malformed.
    """
    logger.debug("Loading draft site YAML from: %s", path)
    data: dict[str, Any] = load_yaml_preserving_quotes(path)

    spec: dict[str, Any] = data.get("spec", {})
    if not isinstance(spec, dict):
        raise ConfigFileError(path=path, reason="'spec' key is not a mapping")

    # Extract top-level spec fields
    url: str = str(spec.get("url", ""))
    version: str = str(spec.get("version", ""))
    custom_properties: dict[str, str] = _extract_custom_properties(spec)

    # Parse version to get year and quarter
    year, quarter = parse_version(version)

    # Extract component replicas and HA mode
    component_replicas = _extract_component_replicas(spec)
    high_availability = _determine_ha_mode(component_replicas)
    service_manager_replicas = component_replicas.get("serviceManager", 0)

    # Extract analytics shard count and engine overrides
    analytics_exec_shard_count = _extract_analytics_exec_shard_count(spec)
    engine_overrides = _extract_engine_overrides(spec)

    # Extract webapp data sources and URL fields
    webapp_section = spec.get("webapp", {})
    if not isinstance(webapp_section, dict):
        webapp_section = {}
    data_sources = _extract_data_sources(webapp_section)
    raw_data_sources_yaml = webapp_section.get("dataSources")
    static_url = _extract_optional_str(webapp_section, "staticUrl")
    dynamic_url = _extract_optional_str(webapp_section, "dynamicUrl")
    application_context = str(webapp_section.get("applicationContext", "suite")) or "suite"

    logger.debug(
        "Parsed spec: url=%s, version=%s (year=%d, quarter=%d), custom_properties=%d keys, ha=%s, "
        "data_sources=%d, static_url=%s, dynamic_url=%s, application_context=%s",
        url,
        version,
        year,
        quarter,
        len(custom_properties),
        high_availability,
        len(data_sources),
        static_url,
        dynamic_url,
        application_context,
    )

    # Partition custom properties into enforced, SMTP, and additional buckets
    enforced_properties, smtp_config, additional_custom_properties, metrics_auth_token = _partition_custom_properties(
        custom_properties
    )

    return ParsedSite(
        url=url,
        version=version,
        year=year,
        quarter=quarter,
        high_availability=high_availability,
        custom_properties=custom_properties,
        additional_custom_properties=additional_custom_properties,
        enforced_properties=enforced_properties,
        smtp=smtp_config,
        component_replicas=component_replicas,
        service_manager_replicas=service_manager_replicas,
        engine_overrides=engine_overrides,
        analytics_exec_shard_count=analytics_exec_shard_count,
        data_sources=data_sources,
        static_url=static_url,
        dynamic_url=dynamic_url,
        application_context=application_context,
        metrics_auth_token=metrics_auth_token,
        raw_data_sources_yaml=raw_data_sources_yaml,
    )


def _extract_custom_properties(spec: dict[str, Any]) -> dict[str, str]:
    """Extract custom properties from the spec mapping.

    Converts all values to strings to ensure a consistent dict[str, str]
    return type regardless of how ruamel.yaml represents scalar values.

    Args:
        spec: The parsed 'spec' section of the Draft Site YAML.

    Returns:
        Dictionary of custom property key-value pairs.
    """
    raw = spec.get("customProperties", {})
    if not isinstance(raw, dict):
        return {}
    return {str(k): str(v) for k, v in raw.items()}


def _extract_optional_str(mapping: dict[str, Any], key: str) -> str | None:
    """Extract an optional string value from a mapping.

    Returns None if the key is absent or has a None value.

    Args:
        mapping: The dictionary to extract from.
        key: The key to look up.

    Returns:
        The string value, or None if absent.
    """
    value = mapping.get(key)
    if value is None:
        return None
    return str(value)


def _extract_data_sources(webapp_section: dict[str, Any]) -> list[DataSource]:
    """Extract data sources from the webapp section.

    Reads the 'dataSources' mapping, which may contain 'primary' and
    'business' entries. Each entry is converted to a DataSource dataclass
    with db_type extracted from the JDBC URL.

    Args:
        webapp_section: The parsed 'webapp' section of the spec.

    Returns:
        List of DataSource instances (empty if dataSources is absent or empty).
    """
    data_sources_section = webapp_section.get("dataSources", {})
    if not isinstance(data_sources_section, dict) or not data_sources_section:
        return []

    data_sources: list[DataSource] = []
    for ds_key in ("primary", "business"):
        ds_config = data_sources_section.get(ds_key)
        if ds_config is None or not isinstance(ds_config, dict):
            continue
        data_source = _build_data_source(ds_config)
        data_sources.append(data_source)

    logger.debug("Extracted %d data source(s)", len(data_sources))
    return data_sources


def _build_data_source(ds_config: dict[str, Any]) -> DataSource:
    """Build a DataSource dataclass from a raw data source configuration dict.

    Calls extract_db_type() on the JDBC URL to populate the db_type field.

    Args:
        ds_config: Raw dictionary from the dataSources section (e.g., primary or business).

    Returns:
        DataSource instance with all fields populated.
    """
    url = str(ds_config.get("url", ""))
    db_type = extract_db_type(url) if url else ""

    # Extract attributes, ensuring dict[str, str]
    raw_attributes = ds_config.get("attributes", {})
    if not isinstance(raw_attributes, dict):
        raw_attributes = {}
    attributes: dict[str, str] = {str(k): str(v) for k, v in raw_attributes.items()}

    return DataSource(
        name=str(ds_config.get("name", "")),
        driver_class_name=str(ds_config.get("driverClassName", "")),
        url=url,
        username=str(ds_config.get("username", "")),
        password_secret_key_ref=str(ds_config.get("passwordSecretKeyRef", "")),
        factory=str(ds_config.get("factory", "")),
        type=str(ds_config.get("type", "")),
        attributes=attributes,
        db_type=db_type,
    )


def _extract_component_replicas(spec: dict[str, Any]) -> dict[str, int]:
    """Extract replica counts for all known components from the spec.

    Iterates over COMPONENT_LIST and reads the 'replicas' field from each
    component's section. Absent components default to 0 replicas.

    Args:
        spec: The parsed 'spec' section of the Draft Site YAML.

    Returns:
        Dictionary mapping component name to replica count.
    """
    replicas: dict[str, int] = {}
    for component in COMPONENT_LIST:
        component_section = spec.get(component, {})
        if isinstance(component_section, dict):
            replicas[component] = int(component_section.get("replicas", 0))
        else:
            replicas[component] = 0
    logger.debug("Extracted component replicas: %s", replicas)
    return replicas


def _determine_ha_mode(component_replicas: dict[str, int]) -> bool:
    """Determine HA mode from the zookeeper replica count.

    HA is true when zookeeper has exactly 3 replicas, false when it has 1,
    and defaults to false for any other value.

    Args:
        component_replicas: Dictionary of component name to replica count.

    Returns:
        True if HA mode, False otherwise.
    """
    zk_replicas = component_replicas.get("zookeeper", 0)
    if zk_replicas == 3:
        return True
    return False


def _extract_analytics_exec_shard_count(spec: dict[str, Any]) -> int | None:
    """Extract the analytics execution shard count from the spec.

    Reads from spec.serviceManager.topology.analyticsExecShardCount.
    Returns None if the field is absent.

    Args:
        spec: The parsed 'spec' section of the Draft Site YAML.

    Returns:
        The shard count integer, or None if not present.
    """
    sm_section = spec.get("serviceManager", {})
    if not isinstance(sm_section, dict):
        return None
    topology = sm_section.get("topology", {})
    if not isinstance(topology, dict):
        return None
    shard_count = topology.get("analyticsExecShardCount")
    if shard_count is None:
        return None
    return int(shard_count)


def _extract_engine_overrides(spec: dict[str, Any]) -> dict[str, int]:
    """Extract per-engine replica overrides from the spec.

    Reads from spec.serviceManager.engineOverrides. Each entry in the
    dict is expected to have a 'replicas' field.

    Args:
        spec: The parsed 'spec' section of the Draft Site YAML.

    Returns:
        Dictionary mapping engine name to replica count.
    """
    sm_section = spec.get("serviceManager", {})
    if not isinstance(sm_section, dict):
        return {}
    overrides_section = sm_section.get("engineOverrides", {})
    if not isinstance(overrides_section, dict):
        return {}
    engine_overrides: dict[str, int] = {}
    for engine_name, engine_config in overrides_section.items():
        if isinstance(engine_config, dict):
            replicas = engine_config.get("replicas")
            if replicas is not None:
                engine_overrides[str(engine_name)] = int(replicas)
    logger.debug("Extracted engine overrides: %s", engine_overrides)
    return engine_overrides


def _partition_custom_properties(
    custom_properties: dict[str, str],
) -> tuple[dict[str, str | int], SmtpConfig | None, dict[str, str], str | None]:
    """Partition custom properties into enforced, SMTP, and additional buckets.

    Each custom property is routed to exactly one destination:
    - Removed properties are discarded entirely.
    - The special 'metricsauthtoken' key is extracted to metrics_auth_token.
    - Enforced properties are mapped to their Helm keys with type coercion.
    - SMTP properties are mapped to SmtpConfig fields with boolean coercion.
    - Remaining properties go to additional_custom_properties.

    Empty/whitespace-only enforced properties are omitted from all output.

    Args:
        custom_properties: All raw custom properties from the input YAML.

    Returns:
        Tuple of (enforced_properties, smtp_config_or_none,
                  additional_custom_properties, metrics_auth_token_or_none).
    """
    enforced_properties: dict[str, str | int] = {}
    smtp_fields: dict[str, str | bool] = {}
    additional_custom_properties: dict[str, str] = {}
    metrics_auth_token: str | None = None

    for key, value in custom_properties.items():
        if key in REMOVED_PROPERTIES:
            logger.debug("Removing property (managed/deprecated): %s", key)
            continue

        if key == "metricsauthtoken":
            metrics_auth_token = value
            logger.debug("Extracted metricsauthtoken")
            continue

        if key in ENFORCED_PROPERTY_MAP:
            helm_path, target_type = ENFORCED_PROPERTY_MAP[key]
            # Omit empty/whitespace-only enforced properties
            if not value or value.strip() == "":
                logger.debug("Omitting empty enforced property: %s", key)
                continue
            if target_type is int:
                try:
                    enforced_properties[helm_path] = int(value)
                except (ValueError, TypeError):
                    logger.warning(
                        "Enforced property '%s' has value '%s' that cannot be parsed as an integer; "
                        "passing through as string.",
                        key,
                        value,
                    )
                    enforced_properties[helm_path] = value
            else:
                enforced_properties[helm_path] = value
            continue

        if key in SMTP_PROPERTY_MAP:
            smtp_key, target_type = SMTP_PROPERTY_MAP[key]
            if target_type is bool:
                smtp_fields[smtp_key] = value.strip().lower() == "true"
            else:
                smtp_fields[smtp_key] = value
            continue

        # Everything else goes to additional
        additional_custom_properties[key] = value

    # Build SmtpConfig only if any SMTP properties were found
    smtp_config: SmtpConfig | None = None
    if smtp_fields:
        smtp_config = SmtpConfig(
            sender_address=smtp_fields.get("senderAddress"),  # type: ignore[arg-type]
            sender_domain=smtp_fields.get("senderDomain"),  # type: ignore[arg-type]
            host=smtp_fields.get("host"),  # type: ignore[arg-type]
            auth=smtp_fields.get("auth"),  # type: ignore[arg-type]
            user=smtp_fields.get("user"),  # type: ignore[arg-type]
            protocol=smtp_fields.get("protocol"),  # type: ignore[arg-type]
            starttls_enabled=smtp_fields.get("starttlsEnabled"),  # type: ignore[arg-type]
            starttls_required=smtp_fields.get("starttlsRequired"),  # type: ignore[arg-type]
            mail_scheme=smtp_fields.get("mailScheme"),  # type: ignore[arg-type]
            mail_server_and_port=smtp_fields.get("mailServerAndPort"),  # type: ignore[arg-type]
        )

    logger.debug(
        "Property partitioning complete: enforced=%d, smtp=%s, additional=%d, metrics_auth_token=%s",
        len(enforced_properties),
        smtp_config is not None,
        len(additional_custom_properties),
        metrics_auth_token is not None,
    )

    return enforced_properties, smtp_config, additional_custom_properties, metrics_auth_token
