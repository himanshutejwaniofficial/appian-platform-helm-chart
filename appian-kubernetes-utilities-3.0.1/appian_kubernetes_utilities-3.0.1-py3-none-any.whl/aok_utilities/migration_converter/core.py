"""Orchestrator module for the migration converter pipeline.

Provides the public entry-point functions `convert()` and `write_output()`
that coordinate the parse → validate → emit pipeline. These functions form
the library-first API consumed by both the CLI layer and programmatic callers.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from aok_utilities.common.exceptions import OutputDirectoryError
from aok_utilities.migration_converter.emitter import build_helm_values_document
from aok_utilities.migration_converter.models import ConversionResult
from aok_utilities.migration_converter.parser import parse_draft_site
from aok_utilities.migration_converter.validator import validate

logger = logging.getLogger(__name__)


def convert(input_path: Path) -> ConversionResult:
    """Parse a Migration Tool draft site YAML and produce Helm values data.

    Orchestrates the full conversion pipeline: parse the input file into
    a structured representation, validate it for non-standard configurations,
    and build the Helm values YAML output.

    Args:
        input_path: Path to the Draft Site YAML file.

    Returns:
        ConversionResult with helm_values dict, warnings list, and yaml_output string.

    Raises:
        ConfigFileError: Input file not found, not readable, or invalid YAML.
        ValueError: Version string does not match expected pattern.
    """
    logger.debug("Starting conversion pipeline for: %s", input_path)

    # Step 1: Parse the input file into a structured representation
    site = parse_draft_site(input_path)

    # Step 2: Validate and accumulate warnings
    warnings = validate(site)

    # Step 3: Build the Helm values YAML string
    yaml_str = build_helm_values_document(site, warnings)

    # Step 4: Parse the YAML string back into a dict for the structured result
    helm_values: dict[str, Any] = yaml.safe_load(yaml_str) or {}

    logger.debug(
        "Conversion pipeline complete: %d warnings, %d top-level keys",
        len(warnings),
        len(helm_values),
    )

    return ConversionResult(
        helm_values=helm_values,
        warnings=warnings,
        yaml_output=yaml_str,
    )


def write_output(result: ConversionResult, output_path: Path) -> None:
    """Write the Helm values YAML to disk.

    Takes a ConversionResult (produced by `convert()`) and writes the
    complete YAML output string to the specified file path, overwriting
    any existing file.

    Args:
        result: The conversion result containing values, warnings, and yaml_output.
        output_path: Destination file path.

    Raises:
        OutputDirectoryError: Output path is not writable (parent directory
            does not exist, insufficient permissions, or other OS-level write failure).
    """
    logger.debug("Writing Helm values output to: %s", output_path)

    try:
        output_path.write_text(result.yaml_output, encoding="utf-8")
    except OSError as exc:
        raise OutputDirectoryError(
            path=output_path,
            reason=f"Cannot write output file: {exc}",
        ) from exc

    logger.debug("Successfully wrote %d bytes to %s", len(result.yaml_output), output_path)
