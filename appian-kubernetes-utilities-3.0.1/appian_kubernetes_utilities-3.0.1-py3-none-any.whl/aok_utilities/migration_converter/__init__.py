"""Migration Converter subcommand for the aok CLI.

Provides the ``aok migration-convert`` subcommand that reads a Migration Tool
draft site YAML and produces a Helm values file for the appian-platform-cs chart.
"""

from __future__ import annotations

import logging
from pathlib import Path

import typer

from aok_utilities.common.exceptions import AokError

from .core import convert, write_output

logger = logging.getLogger(__name__)

app = typer.Typer(help="Convert Migration Tool draft YAML to Helm values.")


@app.callback(invoke_without_command=True)
def migration_convert_command(
    input: Path = typer.Option(..., "-i", "--input", help="Path to Migration Tool draft site YAML"),
    output: Path = typer.Option(
        "appian-platform-cs-values.yaml", "-o", "--output", help="Output Helm values file path"
    ),
    debug: bool = typer.Option(False, "--debug", help="Enable verbose diagnostic output"),
) -> None:
    """Convert a Migration Tool draft site YAML to Helm chart values."""
    if debug:
        logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(name)s: %(message)s")

    try:
        result = convert(input)
        write_output(result, output)
    except AokError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc

    for warning in result.warnings:
        typer.echo(f"  • {warning}")

    warning_count = len(result.warnings)
    typer.echo(f"Wrote {output} ({warning_count} warning{'s' if warning_count != 1 else ''})")
