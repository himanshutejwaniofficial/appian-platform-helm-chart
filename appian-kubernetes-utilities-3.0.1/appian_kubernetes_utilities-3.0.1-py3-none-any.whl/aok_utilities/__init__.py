"""Appian on Kubernetes (AoK) CLI utilities."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__: str = version("appian-kubernetes-utilities")
except PackageNotFoundError:
    __version__ = "0.0.0"
