"""Local HTTP server for serving bundled offline documentation.

Serves the pre-built MkDocs HTML site from the bundled package data
directory using Python's stdlib http.server. Opens the user's default
browser automatically unless suppressed.
"""

from __future__ import annotations

import logging
import socket
import sys
import threading
import webbrowser
from functools import partial
from http.server import SimpleHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def _get_site_directory() -> Path:
    """Resolve the path to the bundled documentation site directory.

    Uses the known location relative to this module file rather than
    importlib.resources, which can return MultiplexedPath objects that
    don't behave as filesystem paths in editable/src-layout installs.

    Returns:
        Path to the directory containing the pre-built MkDocs HTML site.

    Raises:
        SystemExit: If the bundled site directory does not exist or is empty.
    """
    site_path = Path(__file__).parent / "site"

    if not site_path.is_dir():
        logger.error("Bundled documentation site not found at: %s", site_path)
        logger.error("Run 'uv run mkdocs build -d src/aok_utilities/docs_viewer/site' to populate it")
        sys.exit(1)

    # Check for at least an index.html
    index = site_path / "index.html"
    if not index.exists():
        logger.error("Bundled documentation site is empty (no index.html found)")
        logger.error("Run 'uv run mkdocs build -d src/aok_utilities/docs_viewer/site' to populate it")
        sys.exit(1)

    return site_path


def _find_free_port() -> int:
    """Find an available ephemeral port on localhost.

    Returns:
        An available port number.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        port: int = sock.getsockname()[1]
        return port


def serve_docs(port: Optional[int] = None, open_browser: bool = True) -> None:
    """Serve the bundled documentation site on localhost.

    Starts a local HTTP server serving the bundled MkDocs HTML site,
    optionally opens the default browser, and blocks until interrupted
    with Ctrl+C.

    Args:
        port: Port to serve on. If None, an ephemeral port is selected.
        open_browser: Whether to open the default browser to the docs URL.
    """
    site_path = _get_site_directory()
    serve_port = port if port is not None else _find_free_port()

    handler = partial(SimpleHTTPRequestHandler, directory=str(site_path))
    server = HTTPServer(("127.0.0.1", serve_port), handler)

    url = f"http://127.0.0.1:{serve_port}/"

    logger.info("Serving documentation at: %s", url)
    logger.info("Press Ctrl+C to stop the server")

    # Print to stdout for user visibility (not diagnostic — this is the primary output)
    print(f"\n  📖 Documentation available at: {url}")
    print("  Press Ctrl+C to stop\n")

    if open_browser:
        # Open browser in a thread to avoid blocking server start
        threading.Thread(target=webbrowser.open, args=(url,), daemon=True).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Server stopped.")
    finally:
        server.server_close()
