"""Docs Viewer subcommand for the aok CLI.

Provides the ``aok docs`` subcommand that serves the bundled offline
documentation in the user's default browser via a local HTTP server.
"""

from typing import Optional

import typer

from .core import serve_docs

app = typer.Typer(help="Launch bundled documentation in your browser.")


@app.callback(invoke_without_command=True)
def docs_command(
    port: Optional[int] = typer.Option(None, "--port", "-p", help="Port to serve on (default: ephemeral)"),
    no_browser: bool = typer.Option(False, "--no-browser", help="Start server without opening a browser"),
) -> None:
    """Serve the bundled AoK documentation locally and open it in your browser."""
    serve_docs(port=port, open_browser=not no_browser)
