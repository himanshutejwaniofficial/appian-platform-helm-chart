"""Jinja2 template rendering for the Config Generator.

Sets up the Jinja2 environment, loads templates via importlib.resources,
converts configuration dataclasses to template context dictionaries,
and renders selected templates to the output directory.
"""

from __future__ import annotations

import importlib.resources
import logging
from dataclasses import asdict
from pathlib import Path

import jinja2

from aok_utilities.common.exceptions import TemplateRenderError
from aok_utilities.generator.config import GeneratorConfig
from aok_utilities.generator.template_selector import TemplateSelection

logger = logging.getLogger(__name__)


def _get_templates_directory() -> Path:
    """Locate the bundled templates directory via importlib.resources.

    Returns:
        The filesystem path to the ``aok_utilities.generator.templates`` package directory.
    """
    templates_package = importlib.resources.files("aok_utilities.generator.templates")
    # importlib.resources.files() returns a Traversable; for a real package on disk
    # this is a Path-like object we can use directly with Jinja2's FileSystemLoader.
    return Path(str(templates_package))


def _create_jinja2_environment() -> jinja2.Environment:
    """Create and configure the Jinja2 environment for template rendering.

    The environment uses:
    - ``FileSystemLoader`` pointing to the bundled templates directory
    - ``StrictUndefined`` to catch unresolved placeholders at render time
    - ``keep_trailing_newline=True`` to preserve trailing newlines in templates
    - Autoescape disabled (templates produce YAML, SQL, Markdown — not HTML)

    Returns:
        A configured Jinja2 Environment instance.
    """
    templates_dir = _get_templates_directory()
    loader = jinja2.FileSystemLoader(str(templates_dir))

    return jinja2.Environment(
        loader=loader,
        undefined=jinja2.StrictUndefined,
        keep_trailing_newline=True,
        autoescape=False,
    )


def config_to_template_context(config: GeneratorConfig) -> dict[str, object]:
    """Convert typed config to the nested dict structure templates expect.

    Templates use expressions like ``{{ site.namespace }}``, ``{{ repository.appian }}``,
    ``{{ operator.version }}``, ``{{ storage.shared_logs_ha }}``, etc.

    The context dict has top-level keys: ``repository``, ``operator``, ``site``, ``storage``.
    Each contains the dataclass fields as a nested dict.

    For template compatibility, ``site.data_sources`` is exposed as ``site.dataSources``
    (camelCase) in the template context.

    Args:
        config: The validated and defaults-resolved generator configuration.

    Returns:
        A nested dictionary suitable for passing to Jinja2 template rendering.
    """
    context: dict[str, object] = {}

    # Repository section
    repo_dict = asdict(config.repository)
    context["repository"] = repo_dict

    # Operator section
    operator_dict = asdict(config.operator)
    context["operator"] = operator_dict

    # Site section — convert and rename data_sources to dataSources for templates
    site_dict = asdict(config.site)
    # Move data_sources to dataSources for camelCase template compatibility
    if "data_sources" in site_dict:
        site_dict["dataSources"] = site_dict.pop("data_sources")
    context["site"] = site_dict

    # Storage section
    storage_dict = asdict(config.storage)
    context["storage"] = storage_dict

    return context


def render_templates(
    selection: TemplateSelection,
    config: GeneratorConfig,
    output_path: Path,
) -> None:
    """Render all selected templates to the output directory.

    For each ``TemplateTarget`` in ``selection.manifests`` and ``selection.guide``:
    1. Load the Jinja2 template from the bundled templates package
    2. Render it with the config context
    3. Write the output to ``output_path / target.output_path``

    On ``TemplateRenderError`` (unresolved placeholder), log the error and continue
    with remaining templates.

    Args:
        selection: The template selection specifying which templates to render
            and their output paths.
        config: The validated and defaults-resolved generator configuration.
        output_path: The root output directory where rendered files are written.

    Returns:
        None. Files are written to disk as a side effect.
    """
    env = _create_jinja2_environment()
    context = config_to_template_context(config)

    # Combine all targets: manifests + guide
    all_targets = list(selection.manifests) + [selection.guide]

    for target in all_targets:
        try:
            template = env.get_template(target.template_path)
            rendered = template.render(context)

            # Ensure parent directories exist before writing
            output_file = output_path / target.output_path
            output_file.parent.mkdir(parents=True, exist_ok=True)

            output_file.write_text(rendered, encoding="utf-8")
            logger.debug("Rendered template: %s → %s", target.template_path, target.output_path)

        except jinja2.UndefinedError as e:
            # Unresolved placeholder — log and continue with remaining templates
            error = TemplateRenderError(
                template_name=target.template_path,
                placeholder=str(e),
            )
            logger.error("%s", error)

        except jinja2.TemplateNotFound:
            # Template file doesn't exist — log and continue
            logger.error(
                "Template not found: %s (expected at templates/%s)",
                target.template_path,
                target.template_path,
            )
