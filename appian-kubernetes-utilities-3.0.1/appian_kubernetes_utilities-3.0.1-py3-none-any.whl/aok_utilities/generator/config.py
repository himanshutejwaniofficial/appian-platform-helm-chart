"""Configuration parsing, validation, and default resolution.

Defines the configuration dataclasses (``GeneratorConfig`` and its
nested components), validation constants, schema validation logic,
and the ``parse_and_validate()`` entry point.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Validation Constants
# ---------------------------------------------------------------------------

VALID_TOPOLOGIES: set[str] = {"cluster-wide", "main-and-site"}
"""Valid values for ``operator.topology``."""

VALID_WEBHOOK_CERT_MODELS: set[str] = {"cert-manager", "ca-bundle"}
"""Valid values for ``operator.webhookCertModel``."""

VALID_SIZE_CLASSES: set[str] = {"x-small", "small", "medium", "large", "x-large"}
"""Valid values for ``site.class`` (t-shirt sizing)."""

VALID_DB_TYPES: set[str] = {"mysql", "mariadb", "oracle", "postgresql", "sqlserver", "db2"}
"""Valid values for ``site.dataSources.dbType``."""

UNCONDITIONALLY_REQUIRED_FIELDS: list[str] = [
    "repository.appian",
    "operator.topology",
    "operator.webhookCertModel",
    "operator.version",
    "site.namespace",
    "site.name",
    "site.appianPlatformCsHelmChartVersion",
    "site.class",
]
"""Fields that must always be present and non-empty in the config-values file."""


# ---------------------------------------------------------------------------
# Configuration Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class RepositoryConfig:
    """Container image repository configuration.

    Attributes:
        appian: Container image registry path for Appian images.
        helm: OCI Helm registry URL (optional).
        auth_secret_name: Name of the Kubernetes image pull secret.
        auth_username: Registry authentication username.
        auth_password: Registry authentication password.
    """

    appian: str
    helm: Optional[str] = None
    auth_secret_name: Optional[str] = None
    auth_username: Optional[str] = None
    auth_password: Optional[str] = None


@dataclass
class OperatorConfig:
    """Appian Operator deployment configuration.

    Attributes:
        topology: Operator topology — ``"cluster-wide"`` or ``"main-and-site"``.
        webhook_cert_model: Webhook TLS model — ``"cert-manager"`` or ``"ca-bundle"``.
        version: Operator version string (e.g. ``"v0.194.0"``).
        namespace: Kubernetes namespace for the operator. Defaults to ``"appian-operator"``.
        ca_bundle_base64_value: Base64-encoded CA bundle for the ``ca-bundle`` cert model.
    """

    topology: str
    webhook_cert_model: str
    version: str
    namespace: str = "appian-operator"
    ca_bundle_base64_value: Optional[str] = None


@dataclass
class DataSourcesConfig:
    """Database data source configuration for the Appian site.

    Attributes:
        db_type: Target RDBMS platform. Defaults to ``"mysql"``.
        primary_schema_name: Primary database schema name.
        primary_username: Primary database username.
        primary_password: Primary database password.
        business_username: Business database username (optional; triggers business DB provisioning).
        business_password: Business database password.
        business_schema_name: Business database schema name. Defaults to ``"appian"``.
    """

    db_type: str = "mysql"
    primary_schema_name: str = "appian_primary"
    primary_username: str = "PRIMARY_DB_USERNAME"
    primary_password: str = "YOUR_PASSWORD_HERE"
    business_username: Optional[str] = None
    business_password: str = "YOUR_PASSWORD_HERE"
    business_schema_name: str = "appian"


@dataclass
class SiteConfig:
    """Appian site deployment configuration.

    Attributes:
        namespace: Kubernetes namespace for the Appian site.
        name: Site name used in manifests and the deployment guide.
        appian_platform_cs_helm_chart_version: Version of the Appian Platform CS Helm chart.
        size_class: T-shirt sizing class (``"x-small"`` through ``"x-large"``).
        high_availability: Whether the site runs in HA mode with multiple engine replicas.
        shared_storage: Whether the site uses a shared data PVC. Defaults to ``True`` when HA.
        rwx_storage_class_name: ReadWriteMany storage class name for shared PVCs.
        smtp_auth_password: SMTP authentication password for the passwords.properties secret.
        data_sources: Database data source configuration.
    """

    namespace: str
    name: str
    appian_platform_cs_helm_chart_version: str
    size_class: str
    high_availability: bool = False
    shared_storage: bool = False
    rwx_storage_class_name: Optional[str] = None
    smtp_auth_password: Optional[str] = None
    data_sources: DataSourcesConfig = field(default_factory=DataSourcesConfig)


@dataclass
class StorageValues:
    """Storage capacity values determined by the t-shirt size class.

    Each value is a Kubernetes quantity string (e.g. ``"150Gi"``).

    Attributes:
        shared_logs_non_ha: Shared logs PVC capacity for non-HA sites.
        shared_logs_ha: Shared logs PVC capacity for HA sites.
        data_ha: Shared data PVC capacity for HA sites.
        data_non_ha: Shared data PVC capacity for non-HA sites.
    """

    shared_logs_non_ha: str
    shared_logs_ha: str
    data_ha: str
    data_non_ha: str


@dataclass
class GeneratorConfig:
    """Top-level validated configuration for the config generator pipeline.

    Constructed after parsing, validation, and default resolution are complete.

    Attributes:
        repository: Container image repository settings.
        operator: Appian Operator deployment settings.
        site: Appian site deployment settings.
        storage: Storage capacity values for the selected size class.
    """

    repository: RepositoryConfig
    operator: OperatorConfig
    site: SiteConfig
    storage: StorageValues


# ---------------------------------------------------------------------------
# Schema Validation
# ---------------------------------------------------------------------------


def _resolve_dotted_path(raw: dict[str, Any], dotted_path: str) -> Any:
    """Traverse a nested dict using a dotted key path.

    Returns the value at the path, or ``None`` if any segment is missing
    or a non-dict intermediate is encountered.
    """
    keys = dotted_path.split(".")
    current: Any = raw
    for key in keys:
        if not isinstance(current, dict) or key not in current:
            return None
        current = current[key]
    return current


def _is_empty(value: Any) -> bool:
    """Return True if a value is considered empty for validation purposes.

    A value is empty if it is None, or a string that is empty or whitespace-only.
    """
    if value is None:
        return True
    if isinstance(value, str) and value.strip() == "":
        return True
    return False


def validate_schema(raw: dict[str, Any]) -> list[str]:
    """Validate the raw config-values dictionary against the schema.

    Performs all validation checks in a single pass and returns a list of
    error messages. An empty list indicates the configuration is valid.

    Checks performed:
    - Unconditionally required fields are present and non-empty
    - Conditionally required fields based on other field values
    - Enumeration validity for constrained fields
    - Boolean type checks for HA and shared storage fields

    Each error message is prefixed with the full dotted field path.

    Args:
        raw: The parsed config-values dictionary (top-level keys are
            ``repository``, ``operator``, ``site``).

    Returns:
        A list of validation error strings. Empty list means valid.
    """
    errors: list[str] = []

    # --- Unconditionally required fields ---
    for field_path in UNCONDITIONALLY_REQUIRED_FIELDS:
        value = _resolve_dotted_path(raw, field_path)
        if _is_empty(value):
            errors.append(f"{field_path}: required field is missing or empty")

    # --- Enumeration validation ---
    # Only validate enumerations if the field is present and non-empty
    # (missing required fields are already caught above)

    topology = _resolve_dotted_path(raw, "operator.topology")
    if not _is_empty(topology) and topology not in VALID_TOPOLOGIES:
        valid_options = ", ".join(sorted(VALID_TOPOLOGIES))
        errors.append(f"operator.topology: invalid value '{topology}'. Valid options: {valid_options}")

    webhook_cert_model = _resolve_dotted_path(raw, "operator.webhookCertModel")
    if not _is_empty(webhook_cert_model) and webhook_cert_model not in VALID_WEBHOOK_CERT_MODELS:
        valid_options = ", ".join(sorted(VALID_WEBHOOK_CERT_MODELS))
        errors.append(
            f"operator.webhookCertModel: invalid value '{webhook_cert_model}'. Valid options: {valid_options}"
        )

    size_class = _resolve_dotted_path(raw, "site.class")
    if not _is_empty(size_class) and size_class not in VALID_SIZE_CLASSES:
        valid_options = ", ".join(sorted(VALID_SIZE_CLASSES))
        errors.append(f"site.class: invalid value '{size_class}'. Valid options: {valid_options}")

    db_type = _resolve_dotted_path(raw, "site.dataSources.dbType")
    if not _is_empty(db_type) and db_type not in VALID_DB_TYPES:
        valid_options = ", ".join(sorted(VALID_DB_TYPES))
        errors.append(f"site.dataSources.dbType: invalid value '{db_type}'. Valid options: {valid_options}")

    # Boolean type validation for highAvailability and sharedStorage
    high_availability = _resolve_dotted_path(raw, "site.highAvailability")
    if high_availability is not None and not isinstance(high_availability, bool):
        errors.append(f"site.highAvailability: invalid value '{high_availability}'. Must be a boolean (true or false)")

    shared_storage = _resolve_dotted_path(raw, "site.sharedStorage")
    if shared_storage is not None and not isinstance(shared_storage, bool):
        errors.append(f"site.sharedStorage: invalid value '{shared_storage}'. Must be a boolean (true or false)")

    # --- Conditionally required fields ---

    # When webhookCertModel is "ca-bundle", caBundleBase64Value is required
    if webhook_cert_model == "ca-bundle":
        ca_bundle = _resolve_dotted_path(raw, "operator.caBundleBase64Value")
        if _is_empty(ca_bundle):
            errors.append("operator.caBundleBase64Value: required because operator.webhookCertModel is 'ca-bundle'")

    # When highAvailability is true OR sharedStorage is true, rwxStorageClassName is required
    ha_is_true = high_availability is True
    shared_is_true = shared_storage is True
    if ha_is_true or shared_is_true:
        rwx_class = _resolve_dotted_path(raw, "site.rwxStorageClassName")
        if _is_empty(rwx_class):
            if ha_is_true:
                errors.append("site.rwxStorageClassName: required because site.highAvailability is true")
            else:
                errors.append("site.rwxStorageClassName: required because site.sharedStorage is true")

    # authUsername and authPassword must be provided together
    auth_username = _resolve_dotted_path(raw, "repository.authUsername")
    auth_password = _resolve_dotted_path(raw, "repository.authPassword")
    has_username = not _is_empty(auth_username)
    has_password = not _is_empty(auth_password)

    if has_username and not has_password:
        errors.append("repository.authPassword: required because repository.authUsername is provided")
    if has_password and not has_username:
        errors.append("repository.authUsername: required because repository.authPassword is provided")

    return errors


# ---------------------------------------------------------------------------
# Default Resolution and Config Construction
# ---------------------------------------------------------------------------


def resolve_defaults_and_build(raw: dict[str, Any]) -> GeneratorConfig:
    """Resolve default values and construct a GeneratorConfig from a validated raw dict.

    This function assumes that schema validation has already passed. It extracts
    values from the raw dictionary (which uses camelCase keys matching the YAML
    file), applies defaults for optional fields, loads storage sizing values,
    and constructs the typed ``GeneratorConfig`` dataclass.

    Default resolution rules:
        - ``operator.namespace`` → ``"appian-operator"`` if not provided
        - ``site.dataSources.dbType`` → ``"mysql"`` if not provided
        - ``site.dataSources.primarySchemaName`` → ``"appian_primary"`` if not provided
        - ``site.dataSources.primaryUsername`` → ``"PRIMARY_DB_USERNAME"`` if not provided
        - ``site.dataSources.primaryPassword`` → ``"YOUR_PASSWORD_HERE"`` if not provided
        - ``site.dataSources.businessPassword`` → ``"YOUR_PASSWORD_HERE"`` if businessUsername
          is set but businessPassword is not provided
        - ``site.dataSources.businessSchemaName`` → ``"appian"`` if businessUsername is set
          but businessSchemaName is not provided
        - ``site.highAvailability`` → ``False`` if not provided
        - ``site.sharedStorage`` → ``True`` when ``site.highAvailability`` is ``True``
          (if not explicitly set)

    Args:
        raw: The parsed and validated config-values dictionary. Top-level keys
            are ``repository``, ``operator``, and ``site`` with camelCase nested keys.

    Returns:
        A fully constructed ``GeneratorConfig`` with all defaults resolved and
        storage values loaded for the selected size class.
    """
    # Avoid circular import: storage.py imports StorageValues from this module
    from aok_utilities.generator.storage import get_storage_values

    # --- Extract top-level sections ---
    raw_repo: dict[str, Any] = raw.get("repository", {})
    raw_operator: dict[str, Any] = raw.get("operator", {})
    raw_site: dict[str, Any] = raw.get("site", {})
    raw_data_sources: dict[str, Any] = raw_site.get("dataSources", {})

    # --- Build RepositoryConfig ---
    repository = RepositoryConfig(
        appian=raw_repo["appian"],
        helm=raw_repo.get("helm"),
        auth_secret_name=raw_repo.get("authSecretName"),
        auth_username=raw_repo.get("authUsername"),
        auth_password=raw_repo.get("authPassword"),
    )

    # --- Build OperatorConfig with defaults ---
    operator = OperatorConfig(
        topology=raw_operator["topology"],
        webhook_cert_model=raw_operator["webhookCertModel"],
        version=raw_operator["version"],
        namespace=raw_operator.get("namespace", "appian-operator"),
        ca_bundle_base64_value=raw_operator.get("caBundleBase64Value"),
    )

    # --- Resolve site.highAvailability and site.sharedStorage ---
    high_availability: bool = raw_site.get("highAvailability", False)
    shared_storage_raw = raw_site.get("sharedStorage")

    # Default sharedStorage to True when HA is True and not explicitly set
    if shared_storage_raw is None:
        shared_storage = True if high_availability else False
    else:
        shared_storage = bool(shared_storage_raw)

    # --- Build DataSourcesConfig with defaults ---
    business_username = raw_data_sources.get("businessUsername")

    data_sources = DataSourcesConfig(
        db_type=raw_data_sources.get("dbType", "mysql"),
        primary_schema_name=raw_data_sources.get("primarySchemaName", "appian_primary"),
        primary_username=raw_data_sources.get("primaryUsername", "PRIMARY_DB_USERNAME"),
        primary_password=raw_data_sources.get("primaryPassword", "YOUR_PASSWORD_HERE"),
        business_username=business_username,
        business_password=(
            raw_data_sources.get("businessPassword", "YOUR_PASSWORD_HERE")
            if business_username
            else "YOUR_PASSWORD_HERE"
        ),
        business_schema_name=(raw_data_sources.get("businessSchemaName", "appian") if business_username else "appian"),
    )

    # --- Build SiteConfig ---
    site = SiteConfig(
        namespace=raw_site["namespace"],
        name=raw_site["name"],
        appian_platform_cs_helm_chart_version=raw_site["appianPlatformCsHelmChartVersion"],
        size_class=raw_site["class"],
        high_availability=high_availability,
        shared_storage=shared_storage,
        rwx_storage_class_name=raw_site.get("rwxStorageClassName"),
        smtp_auth_password=raw_site.get("smtpAuthPassword"),
        data_sources=data_sources,
    )

    # --- Load storage values for the selected size class ---
    storage = get_storage_values(site.size_class)

    # --- Construct and return GeneratorConfig ---
    return GeneratorConfig(
        repository=repository,
        operator=operator,
        site=site,
        storage=storage,
    )


# ---------------------------------------------------------------------------
# Public Entry Point
# ---------------------------------------------------------------------------


def parse_and_validate(input_path: Path) -> GeneratorConfig:
    """Parse YAML, validate schema, resolve defaults, load storage.

    This is the main entry point for configuration loading. It orchestrates
    the full pipeline: file loading → schema validation → default resolution
    → storage sizing lookup → typed config construction.

    Args:
        input_path: Filesystem path to the config-values YAML file.

    Returns:
        A fully constructed ``GeneratorConfig`` with all defaults resolved
        and storage values loaded.

    Raises:
        ConfigFileError: If the file cannot be read or has invalid YAML syntax.
        ConfigValidationError: If schema validation fails (with all collected errors).
    """
    from aok_utilities.common.exceptions import ConfigValidationError
    from aok_utilities.common.yaml_utils import load_yaml_preserving_quotes

    logger.debug("Loading config file: %s", input_path)
    raw = load_yaml_preserving_quotes(input_path)

    logger.debug("Validating schema")
    errors = validate_schema(raw)
    if errors:
        raise ConfigValidationError(errors)

    logger.debug("Resolving defaults and building config")
    config = resolve_defaults_and_build(raw)

    logger.debug("Configuration loaded successfully")
    return config
