"""Pipeline orchestration for the Config Generator.

Contains the main ``generate()`` function that coordinates the full
generation pipeline: parse → validate → resolve defaults → load storage
→ select templates → prepare output directory → render templates.
"""

import logging
import shutil
from pathlib import Path

from aok_utilities.common.exceptions import (
    ConfigFileError,
    ConfigValidationError,
    OutputDirectoryError,
)
from aok_utilities.common.logging import configure_logging
from aok_utilities.generator.config import parse_and_validate
from aok_utilities.generator.renderer import render_templates
from aok_utilities.generator.template_selector import select_templates

logger = logging.getLogger(__name__)


def prepare_output_directory(output_path: Path, clean: bool) -> None:
    """Create the output directory structure, optionally cleaning first.

    When ``clean`` is True and the directory exists, all contents are removed
    before creating the subdirectory structure. When ``clean`` is False,
    existing files are left in place (they may be overwritten later during
    template rendering).

    The function creates:
      - ``output_path/`` (and any parent directories)
      - ``output_path/manifests/``
      - ``output_path/dependencies/``

    Args:
        output_path: The root output directory path.
        clean: If True, remove all existing contents before creating structure.

    Raises:
        OutputDirectoryError: If any filesystem operation fails (permission
            denied, read-only filesystem, etc.).
    """
    try:
        if clean and output_path.exists():
            logger.debug("Cleaning output directory: %s", output_path)
            for child in output_path.iterdir():
                if child.is_dir():
                    shutil.rmtree(child)
                else:
                    child.unlink()

        output_path.mkdir(parents=True, exist_ok=True)
        (output_path / "manifests").mkdir(exist_ok=True)
        (output_path / "dependencies").mkdir(exist_ok=True)
    except OSError as exc:
        raise OutputDirectoryError(output_path, str(exc)) from exc


def generate(input_path: Path, output_path: Path, clean: bool, debug: bool) -> None:
    """Main pipeline orchestrator for the config generator.

    Executes the full generation pipeline:
    1. Configure logging
    2. Parse and validate the config-values YAML file
    3. Select templates based on configuration
    4. Prepare the output directory
    5. Render all selected templates to the output directory

    Args:
        input_path: Path to the config-values YAML file.
        output_path: Path to the output directory.
        clean: If True, remove output directory contents before generating.
        debug: If True, enable verbose debug logging.

    Raises:
        SystemExit: On any domain error (config file, validation, output dir, rendering).
    """
    configure_logging(debug)

    try:
        logger.debug("Starting config generation pipeline")

        config = parse_and_validate(input_path)

        selection = select_templates(config)
        logger.debug("Selected %d manifest templates + guide", len(selection.manifests))

        prepare_output_directory(output_path, clean)

        render_templates(selection, config, output_path)

        logger.info("Generation complete: %s", output_path)

    except ConfigFileError as exc:
        logger.error("Cannot read config file: %s", exc)
        raise SystemExit(1) from exc

    except ConfigValidationError as exc:
        logger.error("Configuration validation failed:")
        for err in exc.errors:
            logger.error("  • %s", err)
        raise SystemExit(1) from exc

    except OutputDirectoryError as exc:
        logger.error("Output directory error: %s", exc)
        raise SystemExit(1) from exc
