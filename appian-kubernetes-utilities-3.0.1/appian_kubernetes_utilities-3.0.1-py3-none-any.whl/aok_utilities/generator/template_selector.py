"""Template selection logic for the Config Generator.

Determines which Jinja2 templates to render based on the validated
configuration (topology, cert model, HA mode, database type, and
shared storage flag).
"""

from __future__ import annotations

from dataclasses import dataclass

from aok_utilities.generator.config import GeneratorConfig


@dataclass
class TemplateTarget:
    """A single template to render.

    Attributes:
        template_path: Relative path within the templates/ package
            (e.g. ``"operator/operator-values.yaml.j2"``).
        output_path: Relative path within the output directory
            (e.g. ``"manifests/operator-values.yaml"``).
    """

    template_path: str
    output_path: str


@dataclass
class TemplateSelection:
    """Which templates to render and where to write them.

    Attributes:
        manifests: Template targets that produce files in the ``manifests/``
            subdirectory of the output directory.
        guide: Template target that produces the ``DEPLOYMENT.md`` file in
            the root of the output directory.
    """

    manifests: list[TemplateTarget]
    guide: TemplateTarget


def select_templates(config: GeneratorConfig) -> TemplateSelection:
    """Determine which templates to render based on the configuration.

    Selection logic:
        Always included:
            - ``operator/operator-values.yaml.j2`` → ``manifests/operator-values.yaml``
            - ``site/appian-shared-logs-pvc.yaml.j2`` → ``manifests/appian-shared-logs-pvc.yaml``
            - ``site/appian-dbs-{dbType}.sql.j2`` → ``manifests/appian-dbs-{dbType}.sql``
            - ``site/appian-platform-cs-values.yaml.j2`` → ``manifests/appian-platform-cs-values.yaml``

        Conditional:
            - When ``config.site.smtp_auth_password`` is set:
              ``site/passwords.properties.j2`` → ``manifests/passwords.properties``
            - When ``config.site.shared_storage`` is True:
              ``site/appian-shared-data-pvc.yaml.j2`` → ``manifests/appian-shared-data-pvc.yaml``
            - When ``config.operator.webhook_cert_model`` is ``"cert-manager"``:
              - ``operator/cert-manager-selfsigned-cluster-issuer.yaml.j2``
                → ``manifests/cert-manager-selfsigned-cluster-issuer.yaml``
              - ``operator/cert-manager-appian-op-webhooks-cert-secret.yaml.j2``
                → ``manifests/cert-manager-appian-op-webhooks-cert-secret.yaml``
            - When ``config.operator.topology`` is ``"main-and-site"``:
              ``operator/site-operator-values.yaml.j2`` → ``manifests/site-operator-values.yaml``

        Guide (always included):
            - ``guide/DEPLOYMENT.md.j2`` → ``DEPLOYMENT.md``

    Args:
        config: The validated and defaults-resolved generator configuration.

    Returns:
        A ``TemplateSelection`` containing all manifest targets and the guide target.
    """
    manifests: list[TemplateTarget] = []

    # --- Always included manifests ---
    manifests.append(
        TemplateTarget(
            template_path="operator/operator-values.yaml.j2",
            output_path="manifests/operator-values.yaml",
        )
    )

    manifests.append(
        TemplateTarget(
            template_path="site/appian-shared-logs-pvc.yaml.j2",
            output_path="manifests/appian-shared-logs-pvc.yaml",
        )
    )

    db_type = config.site.data_sources.db_type
    manifests.append(
        TemplateTarget(
            template_path=f"site/appian-dbs-{db_type}.sql.j2",
            output_path=f"manifests/appian-dbs-{db_type}.sql",
        )
    )

    manifests.append(
        TemplateTarget(
            template_path="site/appian-platform-cs-values.yaml.j2",
            output_path="manifests/appian-platform-cs-values.yaml",
        )
    )

    # --- Conditional: passwords.properties (only when SMTP password is configured) ---
    if config.site.smtp_auth_password:
        manifests.append(
            TemplateTarget(
                template_path="site/passwords.properties.j2",
                output_path="manifests/passwords.properties",
            )
        )

    # --- Conditional: shared data PVC ---
    if config.site.shared_storage:
        manifests.append(
            TemplateTarget(
                template_path="site/appian-shared-data-pvc.yaml.j2",
                output_path="manifests/appian-shared-data-pvc.yaml",
            )
        )

    # --- Conditional: cert-manager manifests ---
    if config.operator.webhook_cert_model == "cert-manager":
        manifests.append(
            TemplateTarget(
                template_path="operator/cert-manager-selfsigned-cluster-issuer.yaml.j2",
                output_path="manifests/cert-manager-selfsigned-cluster-issuer.yaml",
            )
        )
        manifests.append(
            TemplateTarget(
                template_path="operator/cert-manager-appian-op-webhooks-cert-secret.yaml.j2",
                output_path="manifests/cert-manager-appian-op-webhooks-cert-secret.yaml",
            )
        )

    # --- Conditional: site operator values for main-and-site topology ---
    if config.operator.topology == "main-and-site":
        manifests.append(
            TemplateTarget(
                template_path="operator/site-operator-values.yaml.j2",
                output_path="manifests/site-operator-values.yaml",
            )
        )

    # --- Guide (always included) ---
    guide = TemplateTarget(
        template_path="guide/DEPLOYMENT.md.j2",
        output_path="DEPLOYMENT.md",
    )

    return TemplateSelection(manifests=manifests, guide=guide)
