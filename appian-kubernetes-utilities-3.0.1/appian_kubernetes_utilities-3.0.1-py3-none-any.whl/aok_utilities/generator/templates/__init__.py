"""Bundled Jinja2 templates for the Config Generator."""
