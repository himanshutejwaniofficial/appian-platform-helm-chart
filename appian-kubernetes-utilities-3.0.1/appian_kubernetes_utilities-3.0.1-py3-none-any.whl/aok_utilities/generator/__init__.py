"""Config Generator subcommand for the aok CLI.

Provides the ``aok generate`` subcommand that reads a config-values YAML
file and produces deployment manifests and a deployment guide.
"""

from pathlib import Path

import typer

from .core import generate

app = typer.Typer(help="Generate AoK deployment manifests and guide.")


@app.callback(invoke_without_command=True)
def generate_command(
    input: Path = typer.Option(..., "-i", "--input", help="Path to config-values YAML file"),
    output: Path = typer.Option(..., "-o", "--output", help="Path to output directory"),
    clean: bool = typer.Option(False, "-c", "--clean", help="Remove output directory contents before generating"),
    debug: bool = typer.Option(False, "-d", "--debug", help="Enable verbose diagnostic output"),
) -> None:
    """Generate AoK deployment manifests and guide from a config-values file."""
    generate(input, output, clean, debug)
