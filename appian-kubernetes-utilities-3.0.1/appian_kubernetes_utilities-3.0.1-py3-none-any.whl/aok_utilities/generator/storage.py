"""Embedded storage sizing lookup for AoK t-shirt size classes.

Provides the ``STORAGE_SIZING`` dictionary and ``get_storage_values()``
function that maps a t-shirt size class to its corresponding storage
capacity values.
"""

from aok_utilities.generator.config import StorageValues

STORAGE_SIZING: dict[str, StorageValues] = {
    "x-small": StorageValues(
        shared_logs_non_ha="100Gi",
        shared_logs_ha="200Gi",
        data_ha="100Gi",
        data_non_ha="50Gi",
    ),
    "small": StorageValues(
        shared_logs_non_ha="100Gi",
        shared_logs_ha="200Gi",
        data_ha="100Gi",
        data_non_ha="50Gi",
    ),
    "medium": StorageValues(
        shared_logs_non_ha="150Gi",
        shared_logs_ha="300Gi",
        data_ha="200Gi",
        data_non_ha="100Gi",
    ),
    "large": StorageValues(
        shared_logs_non_ha="200Gi",
        shared_logs_ha="400Gi",
        data_ha="300Gi",
        data_non_ha="150Gi",
    ),
    "x-large": StorageValues(
        shared_logs_non_ha="200Gi",
        shared_logs_ha="400Gi",
        data_ha="300Gi",
        data_non_ha="150Gi",
    ),
}


def get_storage_values(size_class: str) -> StorageValues:
    """Lookup embedded storage values by t-shirt class.

    Args:
        size_class: One of x-small, small, medium, large, x-large.

    Returns:
        StorageValues with the four capacity values for the given class.

    Raises:
        KeyError: If size_class is not a valid t-shirt size.
    """
    try:
        return STORAGE_SIZING[size_class]
    except KeyError:
        valid_classes = ", ".join(sorted(STORAGE_SIZING.keys()))
        raise KeyError(f"Invalid size class '{size_class}'. Valid classes: {valid_classes}") from None
