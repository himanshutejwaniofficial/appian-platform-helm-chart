"""Shared utilities for aok_utilities."""
