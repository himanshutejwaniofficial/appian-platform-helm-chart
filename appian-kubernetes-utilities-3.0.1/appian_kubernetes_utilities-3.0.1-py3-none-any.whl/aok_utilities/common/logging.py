"""Logging configuration for the aok_utilities package.

Provides a single function to configure the package-level logger with
appropriate level and stderr output.
"""

import logging
import sys


def configure_logging(debug: bool) -> None:
    """Configure the aok_utilities logger with level and stderr handler.

    Sets the logging level to DEBUG when debug is True, otherwise INFO.
    Adds a StreamHandler writing to stderr if no handlers are already
    configured on the ``aok_utilities`` logger. On subsequent calls the
    level is updated but no additional handlers are added.

    Args:
        debug: If True, set log level to DEBUG; otherwise set to INFO.
    """
    logger = logging.getLogger("aok_utilities")
    level = logging.DEBUG if debug else logging.INFO
    logger.setLevel(level)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        handler.setLevel(level)
        formatter = logging.Formatter("%(levelname)s: %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    else:
        for existing_handler in logger.handlers:
            existing_handler.setLevel(level)
