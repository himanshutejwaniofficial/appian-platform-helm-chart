"""Appian-specific helpers: version parsing and platform constants.

Provides utilities for interpreting Appian version strings and lists
of known component and engine types used across the aok_utilities
package.
"""

import logging
import re

logger = logging.getLogger(__name__)

COMPONENT_LIST: list[str] = [
    "zookeeper",
    "kafka",
    "searchServer",
    "dataServer",
    "serviceManager",
    "webapp",
    "httpd",
]

SHARDED_ENGINES: list[str] = [
    "analytics",
    "execution",
]

ENGINE_LIST: list[str] = [
    "forums",
    "notifications",
    "notificationsEmail",
    "channels",
    "content",
    "downloadStats",
    "groups",
    "portal",
    "processDesign",
    "analytics",
    "execution",
]

_VERSION_PATTERN: re.Pattern[str] = re.compile(r"^\d{2}\.\d\.\d{3,4}\.0$")


def parse_version(version_str: str) -> tuple[int, int]:
    """Extract year and quarter from an Appian version string.

    The version string must conform to the format ``YY.Q.HHH(H).0`` where
    YY is a two-digit year (00–99), Q is a single digit quarter (1–4),
    and HHH(H) is 3 or 4 digits (allowing hotfix numbers up to 9999).

    Args:
        version_str: Version in format ``YY.Q.HHH(H).0`` (e.g., ``24.3.123.0`` or ``25.3.1001.0``).

    Returns:
        Tuple of (year, quarter).

    Raises:
        ValueError: If version string doesn't match expected pattern
            or quarter is not in the range 1–4.
    """
    if not _VERSION_PATTERN.match(version_str):
        raise ValueError(
            f"Version string '{version_str}' does not match expected format 'YY.Q.HHH(H).0' (e.g. '24.3.123.0' or '25.3.1001.0')"
        )

    parts = version_str.split(".")
    year = int(parts[0])
    quarter = int(parts[1])

    if quarter < 1 or quarter > 4:
        raise ValueError(
            f"Version string '{version_str}' has invalid quarter {quarter}; expected a value between 1 and 4"
        )

    logger.debug("Parsed version '%s' → year=%d, quarter=%d", version_str, year, quarter)
    return year, quarter
