"""Database utility functions for aok_utilities.

Provides helpers for extracting metadata from JDBC connection URLs,
including database type detection with support for vendor-specific
URL variants (e.g., mysql:aws).
"""

import logging
import re

logger = logging.getLogger(__name__)

# Pattern for the mysql:aws JDBC variant: jdbc:mysql:aws://...
_MYSQL_AWS_PREFIX = "jdbc:mysql:aws:"

# Generic JDBC pattern: jdbc:<db_type>:<remainder>
_GENERIC_JDBC_PATTERN = re.compile(r"^jdbc:([^:]+):")


def extract_db_type(jdbc_url: str) -> str:
    """Extract the database type from a JDBC connection URL.

    Handles the ``mysql:aws`` variant by matching ``jdbc:mysql:aws:`` prefix
    before falling back to the generic ``jdbc:<type>:`` pattern.

    Args:
        jdbc_url: JDBC connection URL string (e.g.,
            ``jdbc:mysql:aws://host:3306/db``,
            ``jdbc:postgresql://host:5432/db``).

    Returns:
        Database type string (e.g., ``'mysql:aws'``, ``'mysql'``,
        ``'postgresql'``, ``'mariadb'``, ``'oracle'``, ``'sqlserver'``,
        ``'db2'``).

    Raises:
        ValueError: If the URL does not match any recognised JDBC pattern.
    """
    if jdbc_url.startswith(_MYSQL_AWS_PREFIX):
        logger.debug("Detected mysql:aws JDBC variant in URL: %s", jdbc_url)
        return "mysql:aws"

    match = _GENERIC_JDBC_PATTERN.match(jdbc_url)
    if match:
        db_type = match.group(1)
        logger.debug("Extracted db_type '%s' from URL: %s", db_type, jdbc_url)
        return db_type

    raise ValueError(f"Unable to extract database type from JDBC URL: {jdbc_url!r}")
