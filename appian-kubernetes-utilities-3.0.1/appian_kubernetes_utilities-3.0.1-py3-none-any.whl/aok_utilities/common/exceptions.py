"""Custom exception hierarchy for aok_utilities.

All domain-specific exceptions inherit from AokError, enabling
CLI-facing code to catch a single base class for user-friendly
error presentation.
"""

from pathlib import Path


class AokError(Exception):
    """Base exception for all aok_utilities errors."""


class ConfigFileError(AokError):
    """File not found, not readable, or invalid YAML syntax.

    Attributes:
        path: The filesystem path that caused the error.
        reason: A human-readable description of what went wrong.
    """

    def __init__(self, path: Path, reason: str) -> None:
        self.path = path
        self.reason = reason
        super().__init__(f"{path}: {reason}")


class ConfigValidationError(AokError):
    """Schema validation failed. Contains all collected errors.

    Attributes:
        errors: A list of validation error messages, each prefixed
            with the full dotted field path.
    """

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__(f"Validation failed with {len(errors)} error(s)")


class TemplateRenderError(AokError):
    """A template placeholder could not be resolved.

    Attributes:
        template_name: The name of the template that failed.
        placeholder: The unresolved placeholder expression.
    """

    def __init__(self, template_name: str, placeholder: str) -> None:
        self.template_name = template_name
        self.placeholder = placeholder
        super().__init__(f"Template '{template_name}': unresolved placeholder '{placeholder}'")


class OutputDirectoryError(AokError):
    """Cannot create or clean the output directory.

    Attributes:
        path: The filesystem path that caused the error.
        reason: A human-readable description of what went wrong.
    """

    def __init__(self, path: Path, reason: str) -> None:
        self.path = path
        self.reason = reason
        super().__init__(f"{path}: {reason}")


class ValidationError(AokError):
    """Site YAML schema validation failed.

    Attributes:
        path: The filesystem path to the invalid file.
        field: The field path that failed validation.
        reason: Description of the validation failure.
    """

    def __init__(self, path: Path, field: str, reason: str) -> None:
        self.path = path
        self.field = field
        self.reason = reason
        super().__init__(f"{path}: field '{field}' {reason}")


class DependencyError(AokError):
    """A required external dependency is not available.

    Attributes:
        dependency: Name of the missing dependency.
        instructions: Platform-specific installation instructions.
    """

    def __init__(self, dependency: str, instructions: str) -> None:
        self.dependency = dependency
        self.instructions = instructions
        super().__init__(f"Required dependency '{dependency}' not found. {instructions}")
