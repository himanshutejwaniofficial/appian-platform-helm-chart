"""YAML loading utilities for aok_utilities.

Provides a wrapper around ruamel.yaml that preserves quoted string
values in the parsed output, which is essential for maintaining
fidelity when configuration values contain special characters or
are intentionally quoted.
"""

import logging
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML
from ruamel.yaml.error import YAMLError

from aok_utilities.common.exceptions import ConfigFileError

logger = logging.getLogger(__name__)


def load_yaml_preserving_quotes(path: Path) -> dict[str, Any]:
    """Load a YAML file with quote preservation enabled.

    Uses ruamel.yaml with ``preserve_quotes=True`` so that string
    values retain their original quoting style from the source file.

    Args:
        path: Filesystem path to the YAML file to load.

    Returns:
        A dictionary representing the parsed YAML content.

    Raises:
        ConfigFileError: If the file does not exist, cannot be read
            due to permission errors, or contains invalid YAML syntax.
    """
    try:
        yaml = YAML()
        yaml.preserve_quotes = True
        with path.open("r", encoding="utf-8") as fh:
            data = yaml.load(fh)
    except FileNotFoundError:
        raise ConfigFileError(path, "file not found")
    except PermissionError:
        raise ConfigFileError(path, "permission denied")
    except YAMLError as exc:
        line_info = ""
        if hasattr(exc, "problem_mark") and exc.problem_mark is not None:
            line_info = f" at line {exc.problem_mark.line + 1}"
        problem = getattr(exc, "problem", str(exc))
        raise ConfigFileError(path, f"invalid YAML syntax{line_info}: {problem}")

    if data is None:
        return {}

    if not isinstance(data, dict):
        raise ConfigFileError(path, "expected a YAML mapping at the top level")

    return dict(data)
