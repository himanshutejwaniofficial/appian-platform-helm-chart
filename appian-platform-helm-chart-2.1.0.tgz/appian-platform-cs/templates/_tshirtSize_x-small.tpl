{{/*
		T-SHIRT SIZE: x-small
*/}}

{{/* *********************************************************
		Zookeeper
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-small.zookeeper.storageSize" -}}
{{- "5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.zookeeper.minHeap" -}}
{{- "128m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.zookeeper.maxHeap" -}}
{{- "256m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.zookeeper.cpuRequests" -}}
{{- "10m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.zookeeper.cpuLimits" -}}
{{- "200m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.zookeeper.memoryRequests" -}}
{{- "307Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.zookeeper.memoryLimits" -}}
{{- "448Mi" }}
{{- end }}

{{/* *********************************************************
		Kafka
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-small.kafka.storageSize" -}}
{{- "15Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.kafka.minHeap" -}}
{{- "512m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.kafka.maxHeap" -}}
{{- "1024m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.kafka.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.kafka.cpuLimits" -}}
{{- "2000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.kafka.memoryRequests" -}}
{{- "1229Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.kafka.memoryLimits" -}}
{{- "1792Mi" }}
{{- end }}

{{/* *********************************************************
		Search Server
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-small.searchServer.storageSize" -}}
{{- "5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.searchServer.heap" -}}
{{- "1024m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.searchServer.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.searchServer.cpuLimits" -}}
{{- "300m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.searchServer.memoryRequests" -}}
{{- "1.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.searchServer.memoryLimits" -}}
{{- "3Gi" }}
{{- end }}

{{/* *********************************************************
	Data Server
	*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-small.dataServer.storageSize" -}}
{{- "10Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.dataServer.rtsCount" -}}
{{- 2 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.dataServer.rtsThreads" -}}
{{- 1 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.dataServer.rtsMemoryLimit" -}}
{{- "1GiB" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.dataServer.cpuRequests" -}}
{{- "300m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.dataServer.cpuLimits" -}}
{{- "2" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.dataServer.memoryRequests" -}}
{{- "4Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.dataServer.memoryLimits" -}}
{{- "10Gi" }}
{{- end }}

{{/* *********************************************************
		Service Manager
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.storageSize" -}}
{{- if .Values.highAvailability }}
{{- "2Gi" }}
{{- else }}
{{- "5Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.komodoDirectMemMax" -}}
{{- "512m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.komodoHeapMax" -}}
{{- "1g" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.exec.cpuRequests" -}}
{{- "400m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.analytics.cpuRequests" -}}
{{- "80m" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.tier2.cpuRequests" -}}
{{- "120m" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.default.cpuRequests" -}}
{{- "30m" }}
{{- end }}

{{/* default: cpu limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.default.cpuLimits" -}}
{{- "2000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.exec.memoryRequests" -}}
{{- "2.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.analytics.memoryRequests" -}}
{{- "1Gi" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.tier2.memoryRequests" -}}
{{- "500Mi" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.default.memoryRequests" -}}
{{- "200Mi" }}
{{- end }}

{{/* default: memory limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.x-small.serviceManager.default.memoryLimits" -}}
{{- "32Gi" }}
{{- end }}

{{/* *********************************************************
		Webapp
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-small.webapp.storageSize" -}}
{{- if .Values.highAvailability }}
{{- "2Gi" }}
{{- else }}
{{- "5Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.webapp.maxHeapSize" -}}
{{- "3072m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.webapp.cpuRequests" -}}
{{- "1" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.webapp.cpuLimits" -}}
{{- "4" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.webapp.memoryRequests" -}}
{{- "4.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.webapp.memoryLimits" -}}
{{- "6Gi" }}
{{- end }}

{{/* *********************************************************
		httpd
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-small.httpd.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.httpd.cpuLimits" -}}
{{- "300m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.httpd.memoryRequests" -}}
{{- "600Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-small.httpd.memoryLimits" -}}
{{- "800Mi" }}
{{- end }}
