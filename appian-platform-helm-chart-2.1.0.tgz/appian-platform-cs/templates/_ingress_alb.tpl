{{/*
    Ingress: alb
      
    Parameter passed is .
*/}}

{{- define "appian-platform-cs.ingress.alb" -}}
enabled: true
ingressClassName: "alb"
{{- if .Values.ingressTemplate.hostname }}
hostname: {{ .Values.ingressTemplate.hostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.staticHostname }}
staticHostname: {{ .Values.ingressTemplate.staticHostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.dynamicHostname }}
dynamicHostname: {{ .Values.ingressTemplate.dynamicHostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.tls }}
tls:
{{- include "common.tplvalues.render" ( dict "value" .Values.ingressTemplate.tls "context" $ ) | nindent 2 }}
{{- end }}
annotations:
  alb.ingress.kubernetes.io/healthcheck-interval-seconds: {{ .Values.ingressTemplate.healthcheck.intervalSeconds | default "60" | quote }}
  # healthcheck needs to target /suite/ otherwise it receives a 301 vs expected 200
  alb.ingress.kubernetes.io/healthcheck-path: {{ .Values.ingressTemplate.healthcheck.path | default "/suite/?signin=native" | quote }}
  # healthcheck targets site clusterip service so remains on port 8080 even with HTTPS configured to ingress
  alb.ingress.kubernetes.io/healthcheck-port: {{ .Values.ingressTemplate.healthcheck.port | default "8080" | quote }}
  # healthcheck targets site clusterip service so remains on HTTP even with HTTPS configured to ingress
  alb.ingress.kubernetes.io/healthcheck-protocol: {{ .Values.ingressTemplate.healthcheck.protocol | default "HTTP" | quote }}
  alb.ingress.kubernetes.io/healthcheck-timeout-seconds: {{ .Values.ingressTemplate.healthcheck.timeoutSeconds | default "5" | quote }}
  alb.ingress.kubernetes.io/healthy-threshold-count: {{ .Values.ingressTemplate.healthcheck.healthyThresholdCount | default "5" | quote }}
  {{- if contains "https" .Values.url }}
  # SSL
  # Include HTTP - required for redirect to fix HTTPS falling back to HTTP on return from Apache Web Server (httpd)
  alb.ingress.kubernetes.io/listen-ports: {{ .Values.ingressTemplate.listenPorts | default "[{\"HTTP\": 80}, {\"HTTPS\": 443}]" | squote }}
  # Redirect HTTP to HTTPS to fix HTTPS falling back to HTTP on return from Apache Web Server (httpd)
  # https://kubernetes-sigs.github.io/aws-load-balancer-controller/v2.2/guide/ingress/annotations/#ssl-redirect
  alb.ingress.kubernetes.io/ssl-redirect: "443"
  {{- if .Values.ingressTemplate.certificateReference }}
  alb.ingress.kubernetes.io/certificate-arn: {{ .Values.ingressTemplate.certificateReference }}
  {{- end }}
  {{- else }}
  alb.ingress.kubernetes.io/listen-ports: {{ .Values.ingressTemplate.listenPorts | default "[{\"HTTP\": 80}]" | squote }}
  {{- end }}
  alb.ingress.kubernetes.io/load-balancer-name: {{ .Values.ingressTemplate.loadBalancerName | default .Values.siteName | quote }}
  # alb.ingress.kubernetes.io/scheme default is internal
  alb.ingress.kubernetes.io/scheme: {{ .Values.ingressTemplate.scheme | default "internet-facing" }}
  alb.ingress.kubernetes.io/success-codes: {{ .Values.ingressTemplate.successCodes | default "200" | quote }}
  alb.ingress.kubernetes.io/target-type: {{ .Values.ingressTemplate.targetType | default "ip" }}
  alb.ingress.kubernetes.io/unhealthy-threshold-count: {{ .Values.ingressTemplate.healthcheck.unhealthyThresholdCount | default "2" | quote }}
  # Longer timeout for slow operations like Appian DevOps Compare & Deploy
  alb.ingress.kubernetes.io/load-balancer-attributes: idle_timeout.timeout_seconds={{ .Values.ingressTemplate.requestTimeout | default "300" }}
  {{- if .Values.ingressTemplate.additionalAnnotations }}
  # Additional annotations
  {{- range $key, $val := .Values.ingressTemplate.additionalAnnotations }}
  {{ $key }}: {{ $val | quote }}
  {{- end }}
  {{- end }}
{{- end }}