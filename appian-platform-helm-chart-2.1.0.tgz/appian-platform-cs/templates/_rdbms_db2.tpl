
{{/*
   		Data Source: IBM DB2 UDB
      
      Parameter passed is one of
        .Values.dataSources.primary
        .Values.dataSources.business.[n]
*/}}

{{- define "appian-platform-cs.datasource.db2" -}}
type: javax.sql.DataSource
factory: org.apache.tomcat.jdbc.pool.DataSourceFactory
driverClassName: com.ibm.db2.jcc.DB2Driver
{{- $url := printf "%s%s/%s" "jdbc:db2://" .dbServerAndPort .schemaName }}
{{- $urlParameters := ternary "" .urlParameters (eq .urlParameters nil) }}
{{- $urlWithParams := printf "%s%s%s" $url "?useOldAliasMetadataBehavior=true;" $urlParameters }}
url: {{ $urlWithParams | quote }}
{{- if .usernameSecretKeyRef }}
usernameSecretKeyRef:
  name: {{ .usernameSecretKeyRef.name | quote }}
  key: {{ .usernameSecretKeyRef.key | quote }}
{{- else }}
username: {{ .username | quote }}
{{- end }}
passwordSecretKeyRef:
  name: {{ .passwordSecretKeyRef.name | quote }}
  key: {{ .passwordSecretKeyRef.key | quote }}
attributes:
  {{- if .attributes }}
  {{- include "common.tplvalues.render" ( dict "value" .attributes "context" $ ) | nindent 2 }}
  {{- else }}
  initialSize: "5"
  maxActive: "200"
  defaultTransactionIsolation: "READ_COMMITTED"
  maxWait: "30000"
  minIdle: "5"
  minEvictableIdleTimeMillis: "90000"
  timeBetweenEvictionRunsMillis: "450000"
  validationQuery: "select 1 from sysibm.sysdummy1"
  testOnBorrow: "true"
  {{- end }}
{{- end }}

