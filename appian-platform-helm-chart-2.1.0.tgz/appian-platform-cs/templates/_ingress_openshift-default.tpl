
{{/*
   		Ingress: OpenShift Default
      
      Parameter passed is .
*/}}

{{- define "appian-platform-cs.ingress.openshift-default" -}}
enabled: true
ingressClassName: "openshift-default"
{{- if .Values.ingressTemplate.hostname }}
hostname: {{ .Values.ingressTemplate.hostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.staticHostname }}
staticHostname: {{ .Values.ingressTemplate.staticHostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.dynamicHostname }}
dynamicHostname: {{ .Values.ingressTemplate.dynamicHostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.tls }}
tls:
{{- include "common.tplvalues.render" ( dict "value" .Values.ingressTemplate.tls "context" $ ) | nindent 2 }}
{{- end }}
annotations: # map[string]string     
  # Edge termination
  route.openshift.io/termination: edge

  # Enables operations in Appian with delayed responses, such as application
  # import inspection in Appian Designer, by increasing the timeout for reading a
  # response from the proxied server
  haproxy.router.openshift.io/timeout: {{ .Values.ingressTemplate.requestTimeout | default "300s" | quote }}

  {{- if contains "https" .Values.url }}
  # Suppresses an issue where Apache Web Server (httpd) returns temporary
  # redirects to http:// by setting the text that should be changed in the
  # Location and Refresh header fields of a proxied server response
  route.openshift.io/insecure-policy: Redirect
  {{- end }}

  {{- if .Values.ingressTemplate.additionalAnnotations }}
  
  # Additional annotations
  {{- range $key, $val := .Values.ingressTemplate.additionalAnnotations }}
  {{ $key }}: {{ $val | quote }}
  {{- end }}
  {{- end }}
{{- end }}

