
{{/*
Standard fields common to all components
    .Values.[component] is passed in as the parameter
*/}}
{{- define "appian-platform-cs.componentCommonFields" -}}
{{- if .tolerations }}
tolerations:
{{- include "common.tplvalues.render" ( dict "value" .tolerations "context" $ ) | nindent 2 }}
{{- end }}
{{- if .additionalNetworkPolicyIngressRules }}
additionalNetworkPolicyIngressRules:
{{- include "common.tplvalues.render" ( dict "value" .additionalNetworkPolicyIngressRules "context" $ ) | nindent 2 }}
{{- end }}
{{- if .priorityClassName }}
priorityClassName: {{ .priorityClassName | quote }}
{{- end }}
{{- if .dnsPolicy }}
dnsPolicy: {{ .dnsPolicy | quote }}
{{- end }}
{{- if .dnsConfig }}
dnsConfig:
{{- include "common.tplvalues.render" ( dict "value" .dnsConfig "context" $ ) | nindent 2 }}
{{- end }}
{{- if .podAnnotations }}
podAnnotations:
{{- range $key, $val := .podAnnotations }}
  {{ $key }}: {{ $val | quote }}
{{- end }}
{{- end }}
{{- if .podLabels }}
podLabels:
{{- range $key, $val := .podLabels }}
  {{ $key }}: {{ $val | quote }}
{{- end }}
{{- end }}
{{- if .serviceAccount }}
serviceAccount:
{{- include "common.tplvalues.render" ( dict "value" .serviceAccount "context" $ ) | nindent 2 }}
{{- end }}
{{- end }}