
{{/*
   		Data Source: MySQL and Auora MySQL
      
      Parameter passed is one of
        .Values.dataSources.primary
        .Values.dataSources.business.[n]
*/}}

{{- define "appian-platform-cs.datasource.mysql" -}}
type: javax.sql.DataSource
factory: org.apache.tomcat.jdbc.pool.DataSourceFactory
{{- if eq .dbType "mysql" }}
driverClassName: com.mysql.jdbc.Driver
{{- else if eq .dbType "mysql-aurora" }}
driverClassName: software.aws.rds.jdbc.mysql.Driver
{{- end }}
{{- $protocol := ternary "jdbc:mysql:aws" "jdbc:mysql" (eq .dbType "mysql-aurora") }}
{{- $url := printf "%s%s%s/%s" $protocol "://" .dbServerAndPort .schemaName }}
{{- $urlParameters := ternary "" .urlParameters (eq .urlParameters nil) }}
{{- $urlWithParams := printf "%s%s%s" $url "?useOldAliasMetadataBehavior=true&" $urlParameters }}
url: {{ $urlWithParams | quote }}
{{- if .usernameSecretKeyRef }}
usernameSecretKeyRef:
  name: {{ .usernameSecretKeyRef.name | quote }}
  key: {{ .usernameSecretKeyRef.key | quote }}
{{- else }}
username: {{ .username | quote }}
{{- end }}
passwordSecretKeyRef:
  name: {{ .passwordSecretKeyRef.name | quote }}
  key: {{ .passwordSecretKeyRef.key | quote }}
attributes:
  {{- if .attributes }}
  {{- include "common.tplvalues.render" ( dict "value" .attributes "context" $ ) | nindent 2 }}
  {{- else }}
  initialSize: "5"
  maxActive: "200"
  defaultTransactionIsolation: "READ_COMMITTED"
  maxWait: "30000"
  minIdle: "5"
  minEvictableIdleTimeMillis: "90000"
  timeBetweenEvictionRunsMillis: "450000"
  validationQuery: "SELECT 1"
  testOnBorrow: "true"
  {{- end }}
{{- end }}

