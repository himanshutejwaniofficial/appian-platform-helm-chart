{{/*
		T-SHIRT SIZE: x-large
*/}}

{{/* *********************************************************
		Zookeeper
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-large.zookeeper.storageSize" -}}
{{- "15Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.zookeeper.minHeap" -}}
{{- "128m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.zookeeper.maxHeap" -}}
{{- "256m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.zookeeper.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.zookeeper.cpuLimits" -}}
{{- "200m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.zookeeper.memoryRequests" -}}
{{- "307Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.zookeeper.memoryLimits" -}}
{{- "448Mi" }}
{{- end }}

{{/* *********************************************************
		Kafka
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-large.kafka.storageSize" -}}
{{- "60Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.kafka.minHeap" -}}
{{- "512m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.kafka.maxHeap" -}}
{{- "1024m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.kafka.cpuRequests" -}}
{{- "500m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.kafka.cpuLimits" -}}
{{- "2000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.kafka.memoryRequests" -}}
{{- "1229Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.kafka.memoryLimits" -}}
{{- "1792Mi" }}
{{- end }}

{{/* *********************************************************
		Search Server
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-large.searchServer.storageSize" -}}
{{- "15Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.searchServer.heap" -}}
{{- "5000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.searchServer.cpuRequests" -}}
{{- "250m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.searchServer.cpuLimits" -}}
{{- "8000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.searchServer.memoryRequests" -}}
{{- "7Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.searchServer.memoryLimits" -}}
{{- "14Gi" }}
{{- end }}

{{/* *********************************************************
	Data Server
	*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-large.dataServer.storageSize" -}}
{{- "40Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.dataServer.rtsCount" -}}
{{- 12 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.dataServer.rtsThreads" -}}
{{- 8 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.dataServer.rtsMemoryLimit" -}}
{{- "8GiB" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.dataServer.cpuRequests" -}}
{{- "7" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.dataServer.cpuLimits" -}}
{{- "24" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.dataServer.memoryRequests" -}}
{{- "52Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.dataServer.memoryLimits" -}}
{{- "100Gi" }}
{{- end }}

{{/* *********************************************************
		Service Manager
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.storageSize" -}}
{{- if .Values.highAvailability }}
{{- "2Gi" }}
{{- else }}
{{- "5Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.komodoDirectMemMax" -}}
{{- "768m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.komodoHeapMax" -}}
{{- "1536m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.exec.cpuRequests" -}}
{{- "2250m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.analytics.cpuRequests" -}}
{{- "1250m" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.tier2.cpuRequests" -}}
{{- "1875m" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.default.cpuRequests" -}}
{{- "937m" }}
{{- end }}

{{/* default: cpu limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.default.cpuLimits" -}}
{{- "3600m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.exec.memoryRequests" -}}
{{- "17.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.analytics.memoryRequests" -}}
{{- "9Gi" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.tier2.memoryRequests" -}}
{{- "14Gi" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.default.memoryRequests" -}}
{{- "7Gi" }}
{{- end }}

{{/* default: memory limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.x-large.serviceManager.default.memoryLimits" -}}
{{- "256Gi" }}
{{- end }}

{{/* *********************************************************
		Webapp
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-large.webapp.storageSize" -}}
{{- if .Values.highAvailability }}
{{- "2Gi" }}
{{- else }}
{{- "5Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.webapp.maxHeapSize" -}}
{{- "12288m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.webapp.cpuRequests" -}}
{{- "8" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.webapp.cpuLimits" -}}
{{- "16" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.webapp.memoryRequests" -}}
{{- "14Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.webapp.memoryLimits" -}}
{{- "22Gi" }}
{{- end }}

{{/* *********************************************************
		httpd
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.x-large.httpd.cpuRequests" -}}
{{- "1000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.httpd.cpuLimits" -}}
{{- "1500m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.httpd.memoryRequests" -}}
{{- "900Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.x-large.httpd.memoryLimits" -}}
{{- "1.8Gi" }}
{{- end }}
