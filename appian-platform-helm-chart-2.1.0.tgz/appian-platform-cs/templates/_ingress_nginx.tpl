
{{/*
   		Ingress: nginx
      
      Parameter passed is .
*/}}

{{- define "appian-platform-cs.ingress.nginx" -}}
enabled: true
ingressClassName: "nginx"
{{- if .Values.ingressTemplate.hostname }}
hostname: {{ .Values.ingressTemplate.hostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.staticHostname }}
staticHostname: {{ .Values.ingressTemplate.staticHostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.dynamicHostname }}
dynamicHostname: {{ .Values.ingressTemplate.dynamicHostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.tls }}
tls:
{{- include "common.tplvalues.render" ( dict "value" .Values.ingressTemplate.tls "context" $ ) | nindent 2 }}
{{- end }}
annotations: # map[string]string     
  # Enables large file uploads in Appian by disabling client request body size
  # checks
  # https://kubernetes.github.io/ingress-nginx/user-guide/nginx-configuration/annotations/#custom-max-body-size
  nginx.ingress.kubernetes.io/proxy-body-size: "0"

  # Enables operations in Appian with delayed responses, such as application
  # import inspection in Appian Designer, by increasing the timeout for reading a
  # response from the proxied server
  # https://kubernetes.github.io/ingress-nginx/user-guide/nginx-configuration/annotations/#custom-timeouts
  nginx.ingress.kubernetes.io/proxy-read-timeout: {{ .Values.ingressTemplate.requestTimeout | default "300" | quote }}

  {{- if contains "https" .Values.url }}
  # Suppresses an issue where Apache Web Server (httpd) returns temporary
  # redirects to http:// by setting the text that should be changed in the
  # Location and Refresh header fields of a proxied server response
  # https://kubernetes.github.io/ingress-nginx/user-guide/nginx-configuration/annotations/#proxy-redirect
  nginx.ingress.kubernetes.io/proxy-redirect-from: http://
  nginx.ingress.kubernetes.io/proxy-redirect-to: https://
  {{- end }}

  {{- if .Values.ingressTemplate.additionalAnnotations }}
  
  # Additional annotations
  {{- range $key, $val := .Values.ingressTemplate.additionalAnnotations }}
  {{ $key }}: {{ $val | quote }}
  {{- end }}
  {{- end }}
{{- end }}

