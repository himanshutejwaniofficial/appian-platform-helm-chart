
{{/*
   		Data Source: Oracle
      
      Parameter passed is one of
        .Values.dataSources.primary
        .Values.dataSources.business.[n]
*/}}

{{- define "appian-platform-cs.datasource.oracle" -}}
type: javax.sql.DataSource
factory: org.apache.tomcat.jdbc.pool.DataSourceFactory
driverClassName: oracle.jdbc.OracleDriver
{{- $url := printf "%s%s/%s" "jdbc:oracle:thin:@//" .dbServerAndPort .schemaName }}
{{- $urlParameters := ternary "" .urlParameters (eq .urlParameters nil) }}
{{- $urlWithParams := printf "%s%s%s" $url "?" $urlParameters }}
{{- if .urlParameters }}
url: {{ $urlWithParams | quote }}
{{- else }}
url: {{ $url | quote }}
{{- end }}
{{- if .usernameSecretKeyRef }}
usernameSecretKeyRef:
  name: {{ .usernameSecretKeyRef.name | quote }}
  key: {{ .usernameSecretKeyRef.key | quote }}
{{- else }}
username: {{ .username | quote }}
{{- end }}
passwordSecretKeyRef:
  name: {{ .passwordSecretKeyRef.name | quote }}
  key: {{ .passwordSecretKeyRef.key | quote }}
attributes:
  {{- if .attributes }}
  {{- include "common.tplvalues.render" ( dict "value" .attributes "context" $ ) | nindent 2 }}
  {{- else }}
  initialSize: "5"
  maxActive: "200"
  defaultTransactionIsolation: "READ_COMMITTED"
  maxWait: "30000"
  minIdle: "5"
  minEvictableIdleTimeMillis: "90000"
  timeBetweenEvictionRunsMillis: "450000"
  validationQuery: "select 1 from dual"
  testOnBorrow: "true"
  {{- end }}
{{- end }}

