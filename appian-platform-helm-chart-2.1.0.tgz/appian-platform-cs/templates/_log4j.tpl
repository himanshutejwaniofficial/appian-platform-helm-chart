{{/*
   		Template for log4j customisation
      
      Parameter passed is:
        .Values.webapp.customLoggers.[n]
*/}}

{{- define "appian-platform-cs.log4j_template" -}}
{{ printf "###### CUSTOM LOGGER: %s %s %s" .reference .packageName .loggingLevel }}
{{ printf "log4j.logger.%s=%s, %s" .packageName .loggingLevel .reference }}
{{ printf "log4j.additivity.%s=false" .packageName }}
{{ printf "log4j.appender.%s=org.apache.log4j.RollingFileAppender" .reference }}
{{ printf "log4j.appender.%s.layout=org.apache.log4j.PatternLayout" .reference }}
{{ printf "log4j.appender.%s.layout.ConversionPattern=%s" .reference "%d [%t] %-5p %c - %m%n" }}
{{ printf "log4j.appender.%s.File=${AE_LOGS}/%s.log" .reference .reference }}
{{ printf "log4j.appender.%s.MaxFileSize=10MB" .reference }}
{{ printf "log4j.appender.%s.MaxBackupIndex=1000" .reference }}
{{ printf "log4j.appender.%s.encoding=UTF-8" .reference }}
{{ print "" }}
{{- end }}

