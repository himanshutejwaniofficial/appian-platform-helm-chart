{{/*
Expand the name of the chart.
*/}}
{{- define "appian-platform-cs.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "appian-platform-cs.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "appian-platform-cs.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "appian-platform-cs.labels" -}}
helm.sh/chart: {{ include "appian-platform-cs.chart" . }}
{{ include "appian-platform-cs.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "appian-platform-cs.selectorLabels" -}}
app.kubernetes.io/name: {{ include "appian-platform-cs.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "appian-platform-cs.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "appian-platform-cs.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
----- CUSTOM HELPERS FROM HERE -----
*/}}

{{/*
Renders a value that contains template perhaps with scope if the scope is present.
Usage:
{{ include "common.tplvalues.render" ( dict "value" .Values.path.to.the.Value "context" $ ) }}
{{ include "common.tplvalues.render" ( dict "value" .Values.path.to.the.Value "context" $ "scope" $app ) }}
*/}}
{{- define "common.tplvalues.render" -}}
{{- $value := typeIs "string" .value | ternary .value (.value | toYaml) }}
{{- if contains "{{" (toJson .value) }}
  {{- if .scope }}
      {{- tpl (cat "{{- with $.RelativeScope -}}" $value "{{- end }}") (merge (dict "RelativeScope" .scope) .context) }}
  {{- else }}
    {{- tpl $value .context }}
  {{- end }}
{{- else }}
    {{- $value }}
{{- end }}
{{- end -}}

{{/*
Combine minimal image repository and optional tag
*/}}
{{- define "appian-platform-cs.minimalImageWithTag" -}}
{{- if .Values.images.minimal.tag }}
{{- printf "%s:%s" .Values.images.minimal.repository .Values.images.minimal.tag }}
{{- else }}
{{- .Values.images.minimal.repository }}
{{- end }}
{{- end }}

{{/*
httpd replicas
*/}}
{{- define "appian-platform-cs.httpdReplicas" -}}
{{- if .Values.httpd.replicas }}
{{- .Values.httpd.replicas }}
{{- else }}
{{- .Values.highAvailability | ternary .Values.webapp.replicas 1 | default 3 }}
{{- end }}
{{- end }}

{{- /* Apply a signature annotation to identify sites that have used this chart to generate their spec*/}}
{{- define "appian-platform-cs.signature.annotationSection" -}}
annotations:
  cs.k8s.appian.com/helm-chart: {{ .Chart.Version }}
{{- end }}

{{/*
DEPRECATED - THIS HELPER FUNCTION IS NO LONGER USED. IT IS KEPT AS AN EXAMPLE ONLY.
Default for dataServer.rts.queryMemoryCircuitBreakerThresholdBytes
*/}}
{{- define "appian-platform-cs.calculateRtsQueryMemoryCBDefaultThreshold" -}}
{{- $rtsCount := . | int -}}
{{- if le $rtsCount 2 }}
  {{- 500000000 }}
{{- else if le $rtsCount 4 }}
  {{- 1000000000 }}
{{- else if le $rtsCount 8 }}
  {{- 2000000000 }}
{{- else if le $rtsCount 12 }}
  {{- 4000000000 }}
{{- else }}
  {{- 4000000000 }}
{{- end }}
{{- end }}

