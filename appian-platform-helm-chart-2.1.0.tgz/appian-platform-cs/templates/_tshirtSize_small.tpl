{{/*
		T-SHIRT SIZE: small
*/}}

{{/* *********************************************************
		Zookeeper
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.small.zookeeper.storageSize" -}}
{{- "5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.zookeeper.minHeap" -}}
{{- "128m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.zookeeper.maxHeap" -}}
{{- "256m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.zookeeper.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.zookeeper.cpuLimits" -}}
{{- "200m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.zookeeper.memoryRequests" -}}
{{- "307Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.zookeeper.memoryLimits" -}}
{{- "448Mi" }}
{{- end }}

{{/* *********************************************************
		Kafka
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.small.kafka.storageSize" -}}
{{- "15Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.kafka.minHeap" -}}
{{- "512m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.kafka.maxHeap" -}}
{{- "1024m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.kafka.cpuRequests" -}}
{{- "500m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.kafka.cpuLimits" -}}
{{- "2000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.kafka.memoryRequests" -}}
{{- "1229Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.kafka.memoryLimits" -}}
{{- "1792Mi" }}
{{- end }}

{{/* *********************************************************
		Search Server
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.small.searchServer.storageSize" -}}
{{- "5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.searchServer.heap" -}}
{{- "1024m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.searchServer.cpuRequests" -}}
{{- "200m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.searchServer.cpuLimits" -}}
{{- "300m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.searchServer.memoryRequests" -}}
{{- "1.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.searchServer.memoryLimits" -}}
{{- "3Gi" }}
{{- end }}

{{/* *********************************************************
	Data Server
	*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.small.dataServer.storageSize" -}}
{{- "10Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.dataServer.rtsCount" -}}
{{- 2 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.dataServer.rtsThreads" -}}
{{- 1 }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.dataServer.rtsMemoryLimit" -}}
{{- "1GiB" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.dataServer.cpuRequests" -}}
{{- "1" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.dataServer.cpuLimits" -}}
{{- "2" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.dataServer.memoryRequests" -}}
{{- "4Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.dataServer.memoryLimits" -}}
{{- "10Gi" }}
{{- end }}

{{/* *********************************************************
		Service Manager
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.small.serviceManager.storageSize" -}}
{{- if .Values.highAvailability }}
{{- "2Gi" }}
{{- else }}
{{- "5Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.serviceManager.komodoDirectMemMax" -}}
{{- "512m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.serviceManager.komodoHeapMax" -}}
{{- "1g" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.serviceManager.exec.cpuRequests" -}}
{{- "400m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.serviceManager.analytics.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.small.serviceManager.tier2.cpuRequests" -}}
{{- "200m" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.small.serviceManager.default.cpuRequests" -}}
{{- "100m" }}
{{- end }}

{{/* default: cpu limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.small.serviceManager.default.cpuLimits" -}}
{{- "2000m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.serviceManager.exec.memoryRequests" -}}
{{- "6.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.serviceManager.analytics.memoryRequests" -}}
{{- "3.25Gi" }}
{{- end }}

{{/* tier2: PE, CO, PD engines */}}
{{- define "appian-platform-cs.tshirtSize.small.serviceManager.tier2.memoryRequests" -}}
{{- "2Gi" }}
{{- end }}

{{/* default: all remaining engines */}}
{{- define "appian-platform-cs.tshirtSize.small.serviceManager.default.memoryRequests" -}}
{{- "1Gi" }}
{{- end }}

{{/* default: memory limits are applied to all engines */}}
{{- define "appian-platform-cs.tshirtSize.small.serviceManager.default.memoryLimits" -}}
{{- "32Gi" }}
{{- end }}

{{/* *********************************************************
		Webapp
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.small.webapp.storageSize" -}}
{{- if .Values.highAvailability }}
{{- "2Gi" }}
{{- else }}
{{- "5Gi" }}
{{- end }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.webapp.maxHeapSize" -}}
{{- "3072m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.webapp.cpuRequests" -}}
{{- "2" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.webapp.cpuLimits" -}}
{{- "4" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.webapp.memoryRequests" -}}
{{- "4.5Gi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.webapp.memoryLimits" -}}
{{- "6Gi" }}
{{- end }}

{{/* *********************************************************
		httpd
		*********************************************************
*/}}

{{- define "appian-platform-cs.tshirtSize.small.httpd.cpuRequests" -}}
{{- "300m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.httpd.cpuLimits" -}}
{{- "500m" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.httpd.memoryRequests" -}}
{{- "650Mi" }}
{{- end }}

{{- define "appian-platform-cs.tshirtSize.small.httpd.memoryLimits" -}}
{{- "1Gi" }}
{{- end }}
