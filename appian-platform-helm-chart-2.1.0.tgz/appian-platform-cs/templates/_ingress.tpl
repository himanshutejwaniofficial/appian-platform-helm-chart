
{{/*
   		Ingress Template
      
      Parameter passed is .

      ingressTemplate.name: one of "agic", "alb", "nginx"
*/}}

{{- define "appian-platform-cs.ingress" -}}
{{- if eq .Values.ingressTemplate.name "agic" }}
{{-  include "appian-platform-cs.ingress.agic" . }}
{{- else if eq .Values.ingressTemplate.name "alb" }}
{{-  include "appian-platform-cs.ingress.alb" . }}
{{- else if eq .Values.ingressTemplate.name "nginx" }}
{{-  include "appian-platform-cs.ingress.nginx" . }}
{{- else if eq .Values.ingressTemplate.name "openshift-default" }}
{{-  include "appian-platform-cs.ingress.openshift-default" . }}
{{- end }}
{{- end }}

