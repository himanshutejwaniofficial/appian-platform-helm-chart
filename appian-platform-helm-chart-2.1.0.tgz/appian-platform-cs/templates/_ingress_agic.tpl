{{/*
    Ingress: agic
      
    Parameter passed is .
*/}}

{{- define "appian-platform-cs.ingress.agic" -}}
enabled: true
{{- if .Values.ingressTemplate.hostname }}
hostname: {{ .Values.ingressTemplate.hostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.staticHostname }}
staticHostname: {{ .Values.ingressTemplate.staticHostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.dynamicHostname }}
dynamicHostname: {{ .Values.ingressTemplate.dynamicHostname | quote }}
{{- end }}
{{- if .Values.ingressTemplate.tls }}
tls:
{{- include "common.tplvalues.render" ( dict "value" .Values.ingressTemplate.tls "context" $ ) | nindent 2 }}
{{- end }}
annotations:
  kubernetes.io/ingress.class: "azure/application-gateway"
  appgw.ingress.kubernetes.io/use-private-ip: {{ .Values.ingressTemplate.usePrivateIp | default "false" | quote }}
  # Longer timeout for slow operations like Appian DevOps Compare & Deploy
  appgw.ingress.kubernetes.io/request-timeout: {{ .Values.ingressTemplate.requestTimeout | default "300" | quote }}
  {{- if contains "https" .Values.url }}
  # SSL
  {{- if .Values.ingressTemplate.certificateReference }}
  appgw.ingress.kubernetes.io/appgw-ssl-certificate: {{ .Values.ingressTemplate.certificateReference | quote }}
  {{- end }}
  {{- if .Values.ingressTemplate.trustedRootCertificate }}
  appgw.ingress.kubernetes.io/appgw-trusted-root-certificate: {{ .Values.ingressTemplate.trustedRootCertificate | quote }}
  {{- end }}
  # Redirect HTTP to HTTPS to fix HTTPS falling back to HTTP on return from Apache Web Server (httpd)
  # https://azure.github.io/application-gateway-kubernetes-ingress/annotations/#ssl-redirect
  appgw.ingress.kubernetes.io/ssl-redirect: "true"
  {{- end }}

  # Health probe
  appgw.ingress.kubernetes.io/health-probe-port: {{ .Values.ingressTemplate.healthcheck.port | default "8080" | quote }}
  appgw.ingress.kubernetes.io/health-probe-path: {{ .Values.ingressTemplate.healthcheck.path | default "/suite/?sigin=native" | quote }}
  # Allow 403 Forbidden too as this can be returned by healthy sites and will cause a 502 Bad Gateway if not allowed
  appgw.ingress.kubernetes.io/health-probe-status-codes: "200, 403"
  appgw.ingress.kubernetes.io/health-probe-interval: {{ .Values.ingressTemplate.healthcheck.intervalSeconds | default "60" | quote }}
  appgw.ingress.kubernetes.io/health-probe-timeout: {{ .Values.ingressTemplate.healthcheck.timeoutSeconds | default "5" | quote }}
  appgw.ingress.kubernetes.io/health-probe-unhealthy-threshold: {{ .Values.ingressTemplate.healthcheck.unhealthyThresholdCount | default "2" | quote }}
  {{- if .Values.ingressTemplate.additionalAnnotations }}
  # Additional annotations
  {{- range $key, $val := .Values.ingressTemplate.additionalAnnotations }}
  {{ $key }}: {{ $val | quote }}
  {{- end }}
  {{- end }}
{{- end }}