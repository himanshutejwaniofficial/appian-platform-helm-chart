
{{/*
   		Data Source Template
      
      Parameter passed is one of
        .Values.dataSources.primary
        .Values.dataSources.business.[n]
*/}}

{{- define "appian-platform-cs.datasource" -}}
{{- if or (eq .dbType "mysql") (eq .dbType "mysql-aurora") }}
{{-  include "appian-platform-cs.datasource.mysql" . }}
{{- else if eq .dbType "mariadb" }}
{{-  include "appian-platform-cs.datasource.mariadb" . }}
{{- else if eq .dbType "oracle" }}
{{-  include "appian-platform-cs.datasource.oracle" . }}
{{- else if eq .dbType "mssql" }}
{{-  include "appian-platform-cs.datasource.mssql" . }}
{{- else if or (eq .dbType "postgresql") (eq .dbType "postgresql-aurora") }}
{{-  include "appian-platform-cs.datasource.postgresql" . }}
{{- else if eq .dbType "db2" }}
{{-  include "appian-platform-cs.datasource.db2" . }}
{{- end }}
{{- end }}

